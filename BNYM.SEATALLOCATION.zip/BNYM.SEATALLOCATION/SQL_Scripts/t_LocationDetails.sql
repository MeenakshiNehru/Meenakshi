USE [iLoc]
GO

/****** Object:  Table [dbo].[t_LocationDetails]    Script Date: 8/21/2015 3:38:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_LocationDetails](
	[LocationID] [int] IDENTITY(1,1) NOT NULL,
	[LocationName] [varchar](100) NULL,
	[LocationNo] [varchar](20) NULL,
	[MapID] [int] NULL,
	[CoOrdinateX1] [int] NULL,
	[CoOrdinateY1] [int] NULL,
	[LocationTypeID] [int] NULL,
	[ParentLocationID] [int] NULL,
	[VOIP] [bigint] NULL,
	[ActiveStatus] [bit] NULL,
	[CommitID] [varchar](15) NULL,
	[Shared] [bit] NULL,
	[EmpID] [varchar](15) NULL,
	[GlobalID] [varchar](15) NULL,
	[Blocked] [bit] NULL,
	[UpdatedBy] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[LocationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[t_LocationDetails]  WITH CHECK ADD  CONSTRAINT [FK__t_Locatio__Locat__4BAC3F29] FOREIGN KEY([LocationTypeID])
REFERENCES [dbo].[t_LocationType] ([LocationTypeID])
GO

ALTER TABLE [dbo].[t_LocationDetails] CHECK CONSTRAINT [FK__t_Locatio__Locat__4BAC3F29]
GO

ALTER TABLE [dbo].[t_LocationDetails]  WITH CHECK ADD FOREIGN KEY([MapID])
REFERENCES [dbo].[t_MapDetails] ([MapID])
GO


