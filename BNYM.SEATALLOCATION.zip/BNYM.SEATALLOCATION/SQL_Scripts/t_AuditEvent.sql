USE [iLoc]
GO

/****** Object:  Table [dbo].[t_AuditEvent]    Script Date: 8/21/2015 3:34:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_AuditEvent](
	[AuditEventID] [int] IDENTITY(1,1) NOT NULL,
	[AuditEventName] [varchar](500) NULL,
	[AuditEventDescription] [varchar](1000) NULL,
	[ActiveStatus] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[AuditEventID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


