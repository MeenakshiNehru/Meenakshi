USE [iLoc]
GO

/****** Object:  Table [dbo].[t_UserLocationDetails]    Script Date: 8/21/2015 3:39:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_UserLocationDetails](
	[LocationID] [int] NOT NULL,
	[ComitID] [varchar](8) NOT NULL,
 CONSTRAINT [PK__t_UserLo__1F8B35B6D95590DB] PRIMARY KEY CLUSTERED 
(
	[LocationID] ASC,
	[ComitID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[t_UserLocationDetails]  WITH CHECK ADD FOREIGN KEY([ComitID])
REFERENCES [dbo].[t_UserDetails] ([ComitID])
GO

ALTER TABLE [dbo].[t_UserLocationDetails]  WITH CHECK ADD FOREIGN KEY([LocationID])
REFERENCES [dbo].[t_LocationDetails] ([LocationID])
GO


