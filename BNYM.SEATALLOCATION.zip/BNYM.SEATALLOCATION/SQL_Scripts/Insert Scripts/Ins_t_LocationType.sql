INSERT INTO [dbo].[t_LocationType]
           ([LocationTypeName]
           ,[ActiveStatus])
     VALUES
           ('workstation',1)
GO


