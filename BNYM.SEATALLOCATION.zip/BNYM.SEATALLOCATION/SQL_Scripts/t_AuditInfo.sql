USE [iLoc]
GO

/****** Object:  Table [dbo].[t_AuditInfo]    Script Date: 8/21/2015 3:36:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_AuditInfo](
	[AuditInfoID] [int] IDENTITY(1,1) NOT NULL,
	[AuditEventID] [int] NULL,
	[UpdatedBy] [varchar](8) NULL,
	[UpdatedDateTime] [datetime] NULL,
	[AuditInfoDescription] [varchar](500) NULL,
 CONSTRAINT [PK__t_AuditI__7E568379FD7FBDE3] PRIMARY KEY CLUSTERED 
(
	[AuditInfoID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[t_AuditInfo] ADD  CONSTRAINT [DF__t_AuditIn__Activ__5629CD9C]  DEFAULT (getdate()) FOR [UpdatedDateTime]
GO


