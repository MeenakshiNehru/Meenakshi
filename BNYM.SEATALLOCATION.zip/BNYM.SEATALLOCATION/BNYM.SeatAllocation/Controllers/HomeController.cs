﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BNYM.SeatAllocation.Controllers
{
    public class HomeController : Controller
    {
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Index()
        {
            try
            {
                ViewBag.Message = "Welcome to ASP.NET MVC!";
                //SeatAllocationEntities entity = new SeatAllocationEntities();
                /*List<t_AuditEvent> auditObj = entity.t_AuditEvent.Select(a => a).ToList();
                auditObj[0].AuditEventDescription = "new description";
                entity.SaveChanges();*/

                //if (Convert.ToBoolean(Session["LoginStatus"]) == true)
                    return View("Index");
                //else
                  //  return View("Error");
                   
            }
            catch (Exception ex)
            {
                return View("Error");
            }
        }
        public ActionResult Abandon()
        { 
            Session.Abandon();
            Session.Clear();
           return RedirectToAction("Login");

        }
        public ActionResult Login()
        {
            //Response.Redirect("User/Details");
            Session["UserId"] = string.Empty;
            Session["LoginStatus"] = false;
            return View();
        }
        public ActionResult GetUserRole()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
           List<t_UserDetails> userdetails =  dbentity.t_UserDetails.Select(p=>p).ToList();
           List<t_Roles> Roles = dbentity.t_Roles.Select(p => p).ToList();
           string CommitId = Request["CommitId"].ToString().ToUpper();
            var Role = userdetails.Join(Roles,p=>p.RoleID,q=>q.RoleID,(p,q) => new {Role =q.RoleName,Commit= p.ComitID}).Where(p=>p.Commit.ToUpper() ==CommitId).FirstOrDefault();
          //  Session["LoginStatus"] = false;

            Session["Role"] = "Enterprise Admin"; // Role.Role;
            // Response.Redirect("home/login");
            return Json(Role,JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetCountByCity()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
             List<t_MapDetails> mapdetails = dbentity.t_MapDetails.Select(q=>q).ToList();
             List<t_LocationDetails> locationdetails = dbentity.t_LocationDetails.Select(p => p).ToList();
             //var list = from l in locationdetails
             //           join m in mapdetails on l.MapID equals m.MapID
             //           group m by m.City into a
             //           select new { 
             //               city = a.Key,
             //               cnt = a.Count().ToString() };
             var lst = locationdetails.Join(mapdetails, p => p.MapID, q => q.MapID, (p, q) => new { q.City, p.LocationID }).GroupBy(x => x.City)
                 .Select(y => new geomap { country = y.Key, Count = y.Count() });

            //
             //var l1st = locationdetails.Join(mapdetails, p => p.MapID, q => q.MapID, (p, q) => new { q.City, p.LocationID }).GroupBy(x => x.City)
             //    .SelectMany(y => y.Key);
             return Json(lst, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetCountByMap()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            List<t_MapDetails> mapdetails = dbentity.t_MapDetails.Select(q => q).ToList();
            List<t_LocationDetails> locationdetails = dbentity.t_LocationDetails.Select(p => p).ToList();
            //var list = from l in locationdetails
            //           join m in mapdetails on l.MapID equals m.MapID
            //           group m by m.City into a
            //           select new { 
            //               city = a.Key,
            //               cnt = a.Count().ToString() };

            var lst = locationdetails.Join(mapdetails, p => p.MapID, q => q.MapID, (p, q) => new { q.MapName, p.LocationID,p.CommitID }).Where(p=>p.CommitID==null).GroupBy(x => x.MapName)
                .Select(y => new  { Map = y.Key, Count = y.Count() });

            //
            //var l1st = locationdetails.Join(mapdetails, p => p.MapID, q => q.MapID, (p, q) => new { q.City, p.LocationID }).GroupBy(x => x.City)
            //    .SelectMany(y => y.Key);
            return Json(lst, JsonRequestBehavior.AllowGet);
        }
           [HttpPost]
        public ActionResult GetUnAllocatedCollectionsByMap()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            string MapName = string.Empty;
            List<t_MapDetails> mapdetails = dbentity.t_MapDetails.Select(q => q).ToList();
            List<t_LocationDetails> locationdetails = dbentity.t_LocationDetails.Select(p => p).ToList();
            int EmployeeCount = Convert.ToInt16(Request["EmployeeCount"]);
            List<Array> temp = new List<Array>(); ;
            for (int i = 0; i < mapdetails.Count(); i++)
            {
               MapName= mapdetails[i].MapName.ToString();
               var lst = locationdetails.Join(mapdetails, p => p.MapID, q => q.MapID, (p, q) => new { q.MapName, p.LocationID, p.CommitID, p.CoOrdinateX1, p.CoOrdinateY1,p.LocationNo }).Where(p => p.CommitID == null && p.MapName == MapName).Select(p => p).ToList();
                if(lst.Count() >=EmployeeCount)
               temp.Add(lst.ToArray());
            }
          
            //var list = from l in locationdetails
            //           join m in mapdetails on l.MapID equals m.MapID
            //           group m by m.City into a
            //           select new { 
            //               city = a.Key,
            //               cnt = a.Count().ToString() };
               

            //
            //var l1st = locationdetails.Join(mapdetails, p => p.MapID, q => q.MapID, (p, q) => new { q.City, p.LocationID }).GroupBy(x => x.City)
            //    .SelectMany(y => y.Key);
            return Json(temp, JsonRequestBehavior.AllowGet);
        }
    }

    class geomap
    {
        public string country{get;set;}
        public int Count { get; set; }
    }
}
