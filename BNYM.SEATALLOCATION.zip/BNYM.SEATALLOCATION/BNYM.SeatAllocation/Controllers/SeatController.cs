﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BNYM.SeatAllocation.AdminService;
using BNYM.SeatAllocation.Models;
using Newtonsoft.Json;

namespace BNYM.SeatAllocation.Controllers
{


    public class SeatController : Controller
    {
        //
        // GET: /Seat/

        public ActionResult Index()
        {
            return View();
        }
         [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Seat()
        {
            //if (Convert.ToBoolean(Session["LoginStatus"]) == true && (Session["Role"].ToString() == "iNautix Admin" || Session["Role"].ToString() == "BNYM Admin" || Session["Role"].ToString() == "Enterprise Admin"))
                return View();
            //else
              //  return View("Error");
        }
         [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Search()
        {
            //if (Convert.ToBoolean(Session["LoginStatus"]) == true )
                return View();
            //else
              //  return View("Error");
           
        }
         [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Restacking()
        {
            //if (Convert.ToBoolean(Session["LoginStatus"]) == true && ( Session["Role"].ToString() != "Readonly"))
                return View();
            //else
               // return View("Error");
        }
        [HttpPost]
        public ActionResult ForMappingCommitIdByCenterCoordinates()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
                int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
                bool SharedEntry = Convert.ToBoolean(Request["SharedEntry"]);
              //  bool Blocked = Convert.ToBoolean(Request["Blocked"]);
                if (!SharedEntry)
                {
                    t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                    d_row.CommitID = Request["CommiID"].ToString().ToUpper();
                    d_row.UpdatedBy = Request["UpdatedBy"].ToString().ToUpper();

                   // d_row.Blocked = Blocked;
                    d_row.Blocked = null ;
                }
                else
                { 
                //code here
                    t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                    dbEntity.t_LocationDetails.Add(d_row);
                    d_row.CommitID = Request["CommiID"].ToString().ToUpper();
                    d_row.UpdatedBy = Request["UpdatedBy"].ToString().ToUpper();
                    //d_row.Blocked = Blocked;
                    d_row.Blocked = null;
                }
                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "CommitID Mapped successfully.";
                }
                else
                {
                    result = "Some error occured while Mapping.";
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        
        }
        public ActionResult GetCoordinateDetailsByCommitid()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            string CommitId = Request["CommitId"].ToString().ToUpper();
            var list = locationDetails.Where(p => p.CommitID == CommitId).Select(p => new
            {
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
            }).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCollectionsOfRoles()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            var result = dbentity.t_Roles.Select(p => p).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }
         [HttpPost]
        public ActionResult ForDeallocatingByCenterCoordinatesShared1()
        {
            string result;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
            int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
            string CommitId = Request["CommitId"].ToString().ToUpper();
            List<t_LocationDetails> d_row1 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).ToList();
            if (d_row1.Count == 2)
            {
                t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.CommitID == CommitId).Select(p => p).FirstOrDefault();
                dbEntity.t_LocationDetails.Attach(d_row);
                dbEntity.t_LocationDetails.Remove(d_row);
                d_row.UpdatedBy = Request["UpdatedBy"].ToString().ToUpper();
            }
            else
            {
                t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.CommitID == CommitId).Select(p => p).FirstOrDefault();
                d_row.UpdatedBy = Request["UpdatedBy"].ToString().ToUpper();
                d_row.CommitID = null;
            }
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Deallocated successfully.";
            }
            else
            {
                result = "Some error occured while Deallocation.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ForDeallocatingByCenterCoordinatesShared()
        {
            string result;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
            int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
            List<t_LocationDetails> d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).ToList();
            if (d_row.Count == 1)
            {
                d_row[0].CommitID = null;
                d_row[0].UpdatedBy = Request["UpdatedBy"].ToString().ToUpper(); 
            }
            else
            {
                d_row[0].CommitID = null;
                d_row[0].UpdatedBy = Request["UpdatedBy"].ToString().ToUpper(); 
                dbEntity.SaveChanges();
                dbEntity.t_LocationDetails.Attach(d_row[1]);
                dbEntity.t_LocationDetails.Remove(d_row[1]);
            }
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Deallocated successfully.";
            }
            else
            {
                result = "Some error occured while Deallocation.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ForDeallocatingByCenterCoordinates()
        {
            string result;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
            int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
            string CommitId = Request["CommitId"].ToString().ToUpper();
            t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.CommitID == CommitId).Select(p => p).FirstOrDefault();
            d_row.CommitID = null;
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Deallocated successfully.";
            }
            else
            {
                result = "Some error occured while Deallocation.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ForMappingCommitIdForSharedByCenterCoordinates()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
                int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
                string CommitId1 = Request["CommiID"].ToString().ToUpper();
                string CommitId2 = Request["CommitID2"].ToString().ToUpper();
                t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                d_row.CommitID = CommitId1;
                d_row.UpdatedBy = Request["UpdatedBy"].ToString().ToUpper();
                dbEntity.SaveChanges();
                t_LocationDetails d_row1 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                d_row1.CommitID = CommitId2;
                d_row1.UpdatedBy = Request["UpdatedBy"].ToString().ToUpper();
                dbEntity.t_LocationDetails.Add(d_row1);
                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "CommitID Mapped successfully for shared location.";
                }
                else 
                {
                    result = "Some error occured while Mapping shared location.";
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public ActionResult UpdateLocationDetails()
        {
            try
            {
                string result = string.Empty;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["xCoord"]);
                int Ycoordinate = Convert.ToInt32(Request["yCoord"]);
                string temp = Request["Update"];
                string locNo = Request["locno"].ToString().ToUpper();
                bool Sharing = Convert.ToBoolean(Request["Sharing"]);
                bool CheckBoxCheck = Convert.ToBoolean(Request["CheckBoxChanged"]);
                string UpdatedBy = Request["UpdatedBy"].ToString();
                if (temp == "true")
                {
                    t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                    d_row.LocationNo = locNo;
                    d_row.Shared = Sharing;
                    d_row.UpdatedBy = UpdatedBy;
                    if (Convert.ToBoolean(dbEntity.SaveChanges()))
                    {
                        result = "Location Updated successfully.";
                    }
                    else
                    {
                        result = "Some error occured while Updating.";
                    }
                }
                else if (temp == "false")
                {
                    if (CheckBoxCheck)
                    {
                        List<t_LocationDetails> d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).ToList();
                        if (d_row.Count == 1)
                        {
                            d_row[0].Shared = Sharing;
                            if (Convert.ToBoolean(dbEntity.SaveChanges()))
                            {
                                result = "Location Updated successfully.";
                            }
                            else
                            {
                                result = "Some error occured while Updating.";
                            }
                        }
                        else
                        {
                            t_LocationDetails d_row1 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                            dbEntity.t_LocationDetails.Attach(d_row1);
                            dbEntity.t_LocationDetails.Remove(d_row1);
                            dbEntity.SaveChanges();
                            t_LocationDetails d_row2 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                            d_row1.Shared = Sharing;
                            if (Convert.ToBoolean(dbEntity.SaveChanges()))
                            {
                                result = "Location Updated successfully.";
                            }
                            else
                            {
                                result = "Some error occured while Updating.";
                            }
                        }
                    }
                    else
                    {
                        result = "Location ID Already Exists";
                    }
                    //
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ActionResult DeleteLocationDetails()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["xCoord"]);
                int Ycoordinate = Convert.ToInt32(Request["yCoord"]);
                string locNo = Request["locationnumber"].ToString();
                    List<t_LocationDetails> d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.LocationNo ==locNo).Select(p => p).ToList();
                    if (d_row.Count == 1)
                    {
                        dbEntity.t_LocationDetails.Attach(d_row[0]);
                        dbEntity.t_LocationDetails.Remove(d_row[0]);
                    }
                    else
                    {
                        dbEntity.t_LocationDetails.Attach(d_row[0]);
                        dbEntity.t_LocationDetails.Remove(d_row[0]);
                        dbEntity.SaveChanges();
                        dbEntity.t_LocationDetails.Attach(d_row[1]);
                        dbEntity.t_LocationDetails.Remove(d_row[1]);
                    }
                    if (Convert.ToBoolean(dbEntity.SaveChanges()))
                    {
                        result = "Location Deleted successfully.";
                    }
                    else
                    {
                        result = "Some error occured while Deleting.";
                    }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpPost]
        public ActionResult GetTotalBlockedLocationAcross()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Where(p => p.Blocked == true).Select(p => p).Count();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalBlockedLocationByMapId()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            int MapId = Convert.ToInt32(Request["MapId"]);
            var d_row = dbEntity.t_LocationDetails.Where(p => p.Blocked == true && p.MapID==MapId).Select(p => p).Count();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult BlockUsingCoordinates()
        {
            string result = string.Empty;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            int MapID =  Convert.ToInt16(Request["MapId"]);
            int xcordinate = Convert.ToInt16(Request["XCoordinate"]);
            int ycordinate = Convert.ToInt16(Request["YCoordinate"]);
               bool Blocking = Convert.ToBoolean(Request["Blocking"]);
            t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.MapID == MapID && p.CoOrdinateX1 == xcordinate && p.CoOrdinateY1 == ycordinate).Select(p => p).FirstOrDefault();
            if(Blocking)
                d_row.Blocked = Blocking;
                else
                     d_row.Blocked = null;
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                if(Blocking)
                result = "Location Blocked  successfully.";
                else
                    result = "Location UnBlocked  successfully.";
            }
            else
            {
                if(Blocking)
               result = "Some error occured while Blocking";
                else
                    result = "Some error occured while UnBlocking";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult SaveLocationDetails()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            string result;
            string locNo =    Request["locationNumber"].ToString().ToUpper();
            int xcordinate =Convert.ToInt16( Request["xCoord"].ToString());
            int Ycordinate = Convert.ToInt16(Request["yCoord"]);
            string LocationName = Request["LocationName"].ToString();
            int MapId = Convert.ToInt16(Request["MapId"]);
            int LocationTypeId = Convert.ToInt16(Request["LocationTypeId"]);
            bool ActiveStatus =Convert.ToBoolean(Request["ActiveStatus"]);
            bool Sharing = Convert.ToBoolean(Request["Sharing"]);
            string UpdatedBy = Request["UpdatedBy"].ToString();
            tableObj.LocationNo = locNo;
            tableObj.CoOrdinateX1 = xcordinate;
            tableObj.CoOrdinateY1 = Ycordinate;
            tableObj.LocationName = LocationName;
            tableObj.MapID = MapId;
            tableObj.LocationTypeID = LocationTypeId;
            tableObj.ActiveStatus = ActiveStatus;
            tableObj.Shared = Sharing;
            tableObj.UpdatedBy = UpdatedBy;
            dbEntity.t_LocationDetails.Add(tableObj);
            if(Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Location added successfully.";
            }
            else
            {
                result = "Some error occured while saving.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetLocationDetails()
        {

            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            //List<t_UserLocationDetails> lstLocatoinMapping = new SeatModel().GetUserLocationDetails();
            List<t_UserDetails> lst = new SeatModel().GetUserDetails();

           /* var list = (from locDet in locationDetails
                        join locMap in lstLocatoinMapping on locDet.LocationID equals locMap.LocationID
                        join usr in lst on locMap.ComitID equals usr.ComitID
                        select new
                        {
                            LocationID = locDet.LocationID,
                            LocationNo = locDet.LocationNo,
                            CommitID = locMap.ComitID,
                            XCoOrdinate = locDet.CoOrdinateX1,
                            YCoOrdinate = locDet.CoOrdinateY1,
                            FirstName = usr.FirstName,
                            LastName = usr.LastName,
                            Voip = locDet.VOIP,
                            Department = " ",
                            Team = " ",
                            EmailID = " ",
                        }).ToList();
            */

            /* var list = locationDetails.Select(p => new
              {
                  LocationNo = p.LocationNo,
                  CommitID =  lstLocatoinMapping.Where(l=>l.LocationID==p.LocationID).Select(l=>l.ComitID),
                  XCoOrdinate = p.CoOrdinateX1,
                  YCoOrdinate = p.CoOrdinateY1,
                  FirstName = lst.Where(u => u.ComitID == CommitID).Select(u => u.FirstName),
                  LastName = lst.Where(u => u.ComitID == "").Select(u => u.LastName),
                  Voip = p.VOIP,
                  Department = " ",
                  Team = " ",
                  EmailID = " ",
              }).ToList();*/
            return Json(lst, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SwapLocations()
        {
            string result= string.Empty;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            string Com1ID = Request["Emp1ID"].ToString().ToUpper();
            string Com2ID = Request["Emp2ID"].ToString().ToUpper();
            string locNo1 = Request["Loc1"].ToString();
            string locNo2 = Request["Loc2"].ToString();
            t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CommitID == Com1ID && p.LocationNo == locNo2).Select(p => p).FirstOrDefault();
            t_LocationDetails d_row1 = dbEntity.t_LocationDetails.Where(p => p.CommitID == Com2ID && p.LocationNo == locNo1).Select(p => p).FirstOrDefault();
            int XCoordinate1 = Convert.ToInt32( d_row.CoOrdinateX1);
             int YCoordinate1 = Convert.ToInt32( d_row.CoOrdinateY1);
             int XCoordinate2 = Convert.ToInt32( d_row1.CoOrdinateX1);
             int YCoordinate2 = Convert.ToInt32( d_row1.CoOrdinateY1);
            //d_row.CoOrdinateX1 = XCoordinate2;
            //d_row.CoOrdinateY1 = YCoordinate2;
            d_row.CommitID = Com2ID;
            //d_row1.CoOrdinateX1 = XCoordinate1;
            //d_row1.CoOrdinateY1 = YCoordinate1;
            d_row1.CommitID = Com1ID;
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Location Swaped successfully.";
            }
            else
            {
                result = "Some error occured while Swaping.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetTotalSharedLocationAcross()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            var list = locationDetails.Where(p => p.Shared == true).Select(p => p.LocationNo).Distinct().Count();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
    [HttpPost]
        public JsonResult GetCollections(string term)
        {
         SeatAllocationEntities dbEntity = new SeatAllocationEntities();
  List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_MapDetails> MapLocation = dbEntity.t_MapDetails.Select(p=>p).ToList();
            int i = Convert.ToInt32(Request["MapIndex"]);
            dynamic list=0;
          //  string temp = string.Empty;
            if (i == 1)
            {
                list = locationDetails.Join(MapLocation, p => p.MapID, q => q.MapID, (p, q) => new { CommitId = p.CommitID }).Where(p => p.CommitId != null && p.CommitId.StartsWith(term.ToUpper())).Select(p => p.CommitId).Take(30);
               
                //foreach (dynamic str in list)
                //{
                    
                //    if( temp.Length==0)
                //    {
                //        temp = Convert.ToString(str.CommitId);
                //    }
                //    else
                //    {
                //        temp += "," + Convert.ToString(str.CommitId);
                //    }
                //}
            }
           else if (i == 2)
            {
                 list = locationDetails.Join(MapLocation, p => p.MapID, q => q.MapID, (p, q) => new { LocationNo = p.LocationNo }).Where(p=>p.LocationNo.StartsWith(term)).Select(p=>p.LocationNo).Take(30).ToList();
            }
            else if (i == 3)
            {
                // list = locationDetails.Join(MapLocation, p => p.MapID, q => q.MapID, (p, q) => new { CommitId = p.CommitID }).ToList();
            }
            else if (i == 4)
            {
                 //list = locationDetails.Join(MapLocation, p => p.MapID, q => q.MapID, (p, q) => new { CommitId = p. }).ToList();
            }
            else if (i == 5)
            {
                 //list = locationDetails.Join(MapLocation, p => p.MapID, q => q.MapID, (p, q) => new { CommitId = p.CommitID }).ToList();
                AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
                // string EMpid = Request["EmpID"].ToString();
                List<EmployeeDataContract> obj = objClient.GetResourceDetails(term.ToString().ToUpper()).ToList();
                // List<EmployeeDataContract> obj = objClient.GetResourceDetails(term.ToString().ToUpper()).ToList();
                list = obj.Select(p => p.EmployeeName).Take(30).ToList();
            }
            else if (i == 6)
            {
                AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
               // string EMpid = Request["EmpID"].ToString();
                List<EmployeeDataContract> obj = objClient.GetResourceDetails(term.ToString().ToUpper()).ToList();
               // List<EmployeeDataContract> obj = objClient.GetResourceDetails(term.ToString().ToUpper()).ToList();
                list = obj.Select(p => p.EmployeeName).Take(30).ToList();
              //  list = locationDetails.Join(MapLocation, p => p.MapID, q => q.MapID, (p, q) => new { CommitId = p.CommitID }).ToList();
            }
           // var list = locationDetails.Where(p => p.Shared == true).Select(p => p.LocationNo).Distinct().Count();
          return Json(list, JsonRequestBehavior.AllowGet);
           // return JsonConvert.SerializeObject(list);
        }

        public ActionResult GetCollectonsForParticularMapWithoutDistinct()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_MapDetails> mapDetails = new SeatAllocationEntities().t_MapDetails.Select(p => p).ToList();
            string MapName = Request["MapName"].ToString();
            var list = locationDetails.Join(mapDetails, p => p.MapID, q => q.MapID, (p, q) => new
            {
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
                LocationNo = p.LocationNo,
                CommitId = p.CommitID,
                Shared = p.Shared,
                MapName = q.MapName
            }).Where(z => z.MapName == MapName && z.CommitId != null).Select(p => p.LocationNo).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetDistinctCollectons()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_MapDetails> mapDetails = new SeatAllocationEntities().t_MapDetails.Select(p => p).ToList();
            string MapName = Request["MapName"].ToString();
            var list = locationDetails.Join(mapDetails, p => p.MapID, q => q.MapID, (p, q) => new
            {
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
                LocationNo = p.LocationNo,
                CommitId = p.CommitID,
                Shared = p.Shared,
                MapName = q.MapName
            }).Where(z => z.MapName == MapName && z.CommitId != null).Select(p => p.LocationNo).Distinct().ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetCoordinateDetails()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_MapDetails> mapDetails = new SeatAllocationEntities().t_MapDetails.Select(p => p).ToList();
            // List<t_UserDetails> lst = new SeatModel().GetUserDetails();
            // string key = Request["Prathaban"].ToString();
            var list = locationDetails.Join(mapDetails, p => p.MapID, q => q.MapID, (p,q) => new
            {
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
                LocationNo = p.LocationNo,
                CommitId = p.CommitID,
                Shared = p.Shared,
                MapName = q.MapName,
                Blocked = p.Blocked
            }).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        /*
        [HttpPost]
        public ActionResult GetLocationDetails()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_UserDetails> lst = new SeatModel().GetUserDetails();
            var list = locationDetails.Select(p => new
            {
                LocationNo = p.LocationNo,
                CommitID = p.ComitID,
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
                FirstName = lst.Where(u => u.ComitID == p.ComitID).Select(u => u.FirstName),
                LastName = lst.Where(u => u.ComitID == p.ComitID).Select(u => u.LastName),
                Voip = p.VOIP,
                Department = " ",
                Team = " ",
                EmailID = " ",
            }).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }*/
        //
        // GET: /Seat/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Seat/Create

        public ActionResult Create()
        {
            return View();
        }
         [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Entry()
        {
            //if (Convert.ToBoolean(Session["LoginStatus"]) == true && (Session["Role"].ToString() == "iNautix Admin" || Session["Role"].ToString() == "BNYM Admin" || Session["Role"].ToString() == "Enterprise Admin"))
                return View();
            //else
              //  return View("Error");
        }

        //
        // POST: /Seat/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Seat/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Seat/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Seat/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Seat/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        [HttpPost]
        public ActionResult GetCollectionsByEmpID()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            string EMpid = Request["EmpID"].ToString();
            List<EmployeeDataContract> obj = objClient.GetEmployees(EMpid).ToList();
            if (obj.Count == 0)
            {
                int obj1 = 0;
                return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetAllDepartmentNames()
        { 
         AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
        List<string> DeptName = objClient.GetDepartments().ToList();
        return Json(DeptName, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetDepartmentCollections()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();

            List<EmployeeDataContract> obj = objClient.GetResourceDetails(Request["Dept"].ToString()).Where(q => q.Department == Request["Dept"].ToString()).ToList();
            if (obj.Count == 0)
            {
                int obj1 = 0;
                return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetCommitIdByEmployeeName()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();

            var obj = objClient.GetResourceDetails(Request["EmployeeName"].Substring(0,5)).Where(q => q.EmployeeName.ToLower() == Request["EmployeeName"].ToLower()).Select(p => p.CommitId).FirstOrDefault();
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            var CommitId = dbentity.t_LocationDetails.Where(p => p.CommitID == obj).Select(p => p.CommitID).ToList();

            return Json(CommitId, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetCommitIdByEmployeeId()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();

            var obj = objClient.GetResourceDetails(Request["EmployeeId"]).Where(q => q.EmpId.ToString().ToLower() == Request["EmployeeId"].ToLower()).Select(p => p.CommitId).FirstOrDefault();
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            var CommitId = dbentity.t_LocationDetails.Where(p => p.CommitID == obj).Select(p => p.CommitID).ToList();

            return Json(CommitId, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetUseName()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetHierarchy(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
                int obj1 = 0;
                return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetEmployeesCollectionByManagerCommitID()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetHierarchy(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
                int obj1 = 0;
                return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
         public ActionResult GetEmployeesByLocationNumber()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetEmployees(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
               int obj1 = 0;
               return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet); 
        }
    
        [HttpPost]
        public ActionResult GetEmployeesByComitId()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetEmployees(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
               int obj1 = 0;
               return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet); 
        }
        [HttpPost]
        public ActionResult GetCommitIDbyLocationNumber()
        {
            string LocationNo = Request["LocationNo"].ToString().ToUpper(); ;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Where(u => u.LocationNo == LocationNo).Select(p => p.CommitID).Distinct().ToList(); ;
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalLocationNumbers()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Select(p => p.LocationNo).Distinct().ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalSharedSystems()
        {
           // SeatAllocationEntities dbEntity = new SeatAllocationEntities();
           //var d_row = dbEntity.t_LocationDetails.Where(u => u.Shared==true ).Select(p => p.LocationNo).Distinct().ToList();
           //return Json(d_row.Count(), JsonRequestBehavior.AllowGet);
           List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
           List<t_MapDetails> mapDetails = new SeatAllocationEntities().t_MapDetails.Select(p => p).ToList();
           string MapName = Request["MapName"].ToString();
           var list = locationDetails.Join(mapDetails, p => p.MapID, q => q.MapID, (p, q) => new
           {
               Shared = p.Shared,
               LocationNo = p.LocationNo,
               MapName = q.MapName
           }).Where(z => z.MapName == MapName && z.Shared==true ).Select(z=>z.LocationNo).Distinct().ToList();
           return Json(list, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalEmployeesCommitIdAndLocationNumner()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Where(u => u.CommitID != null).Select(p => new
            {
                CommitID=p.CommitID,
               LocationNo= p.LocationNo,
        }).Distinct().ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalSharedEmployees()
        {
            //SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            //var d_row = dbEntity.t_LocationDetails.Where(u => u.Shared == true && u.CommitID !=null).Select(p => p.LocationNo).Distinct().ToList();
            //return Json(d_row.Count(), JsonRequestBehavior.AllowGet);
                        List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_MapDetails> mapDetails = new SeatAllocationEntities().t_MapDetails.Select(p => p).ToList();
            string MapName = Request["MapName"].ToString();
            var list = locationDetails.Join(mapDetails, p => p.MapID, q => q.MapID, (p, q) => new
            {
                CommitID = p.CommitID,
                Shared = p.Shared,
                LocationNo = p.LocationNo,
                MapName = q.MapName
            }).Where(u => u.Shared == true && u.CommitID != null && u.MapName==MapName).Select(z=>z.CommitID).Distinct().ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetCommitIDByCoordinates()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            int Xcoordinate = Convert.ToInt32(Request["xCoord"]);
            int Ycoordinate = Convert.ToInt32(Request["yCoord"]);
            var d_row = dbEntity.t_LocationDetails.Where(u => u.CoOrdinateX1 == Xcoordinate && u.CoOrdinateY1 == Ycoordinate).Select(p => p.CommitID).Distinct().ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult LoginAuthenticate(string Userid,string Password)
        {
                //string Userid = Request["Userid"].ToString();
                //string Password = Request["Password"].ToString();
                string sDomain = string.Empty;
                string sUserID = string.Empty;
                if (Userid.IndexOf(@"\") > 0)
                {
                    sDomain = Userid.Substring(0, Userid.IndexOf(@"\"));
                    sUserID = Userid.Substring(Userid.IndexOf(@"\") + 1);
                }
                else
                {
                    sUserID = Userid;
                }
                string sPassword = Password;
                bool bStatus = false;
                bStatus = AuthenticateUserByLDAP(sDomain, sUserID, sPassword);
                Session["UserId"] = sUserID;
                Session["LoginStatus"] = bStatus.ToString();
                return Json(bStatus,JsonRequestBehavior.AllowGet);
        }


          public bool AuthenticateUserByLDAP(string sDomain, string sUserID, string sPassword)
    {
        bool bIsAuthenticated = false;
        try
        {
            using (DirectoryEntry de = new DirectoryEntry("LDAP://" + sDomain, sUserID, sPassword))
            {
                using (DirectorySearcher adSearch = new DirectorySearcher(de))
                {
                    //adSearch.Filter = "(sAMAccountName=" + sUserID + ")";
                    try
                    {
                        SearchResult adSearchResult = adSearch.FindOne();
                        bIsAuthenticated = true;
                    }
                    catch (Exception objExp)
                    {
                       // lblInvalidCredentials.Text = objExp.Message + " - Your account will get locked after three consecutive incorrect password.";
                        bIsAuthenticated = false;
                        return bIsAuthenticated;
                    }
                }
            }

        }
        catch (Exception objExp)
        {
            throw objExp;
        }
        return bIsAuthenticated;
    }


    }
}
