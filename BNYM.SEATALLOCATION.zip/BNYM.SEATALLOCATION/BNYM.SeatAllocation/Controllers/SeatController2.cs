﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BNYM.SeatAllocation.AdminService;
using BNYM.SeatAllocation.Models;

namespace BNYM.SeatAllocation.Controllers
{


    public class SeatController : Controller
    {
        //
        // GET: /Seat/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Seat()
        {
            return View();
        }

        public ActionResult Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ForMappingCommitIdByCenterCoordinates()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
                int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
                bool SharedEntry = Convert.ToBoolean(Request["SharedEntry"]);
                if (!SharedEntry)
                {
                    t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                    d_row.CommitID = Request["CommiID"].ToString().ToUpper();
                }
                else
                { 
                //code here
                    t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                    dbEntity.t_LocationDetails.Add(d_row);
                    d_row.CommitID = Request["CommiID"].ToString().ToUpper();
                }
                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "CommitID Mapped successfully.";
                }
                else
                {
                    result = "Some error occured while Mapping.";
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ActionResult GetCoordinateDetailsByCommitid()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            string CommitId = Request["CommitId"].ToString().ToUpper();
            var list = locationDetails.Where(p => p.CommitID == CommitId).Select(p => new
            {
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
            }).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
         [HttpPost]
        public ActionResult ForDeallocatingByCenterCoordinatesShared1()
        {
            string result;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
            int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
            string CommitId = Request["CommitId"].ToString().ToUpper();
            List<t_LocationDetails> d_row1 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).ToList();
            if (d_row1.Count == 2)
            {
                t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.CommitID == CommitId).Select(p => p).FirstOrDefault();
                dbEntity.t_LocationDetails.Attach(d_row);
                dbEntity.t_LocationDetails.Remove(d_row);
            }
            else
            {
                t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.CommitID == CommitId).Select(p => p).FirstOrDefault();
                d_row.CommitID = null;
            }
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Deallocated successfully.";
            }
            else
            {
                result = "Some error occured while Deallocation.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ForDeallocatingByCenterCoordinatesShared()
        {
            string result;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
            int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
            List<t_LocationDetails> d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).ToList();
            if (d_row.Count == 1)
            {
                d_row[0].CommitID = null;
            }
            else
            {
                d_row[0].CommitID = null;
                dbEntity.SaveChanges();
                dbEntity.t_LocationDetails.Attach(d_row[1]);
                dbEntity.t_LocationDetails.Remove(d_row[1]);
            }
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Deallocated successfully.";
            }
            else
            {
                result = "Some error occured while Deallocation.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ForDeallocatingByCenterCoordinates()
        {
            string result;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
            int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
            string CommitId = Request["CommitId"].ToString().ToUpper();
            t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.CommitID == CommitId).Select(p => p).FirstOrDefault();
            d_row.CommitID = null;
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Deallocated successfully.";
            }
            else
            {
                result = "Some error occured while Deallocation.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ForMappingCommitIdForSharedByCenterCoordinates()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["XCenter"]);
                int Ycoordinate = Convert.ToInt32(Request["YCenter"]);
                string CommitId1 = Request["CommiID"].ToString().ToUpper();
                string CommitId2 = Request["CommitID2"].ToString().ToUpper();
                t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                d_row.CommitID = CommitId1;
                dbEntity.SaveChanges();
                t_LocationDetails d_row1 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                d_row.CommitID = CommitId2;
                dbEntity.t_LocationDetails.Add(d_row1);
                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "CommitID Mapped successfully for shared location.";
                }
                else 
                {
                    result = "Some error occured while Mapping shared location.";
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public ActionResult UpdateLocationDetails()
        {
            try
            {
                string result = string.Empty;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["xCoord"]);
                int Ycoordinate = Convert.ToInt32(Request["yCoord"]);
                string temp = Request["Update"];
                string locNo = Request["locno"].ToString();
                bool Sharing = Convert.ToBoolean(Request["Sharing"]);
                bool CheckBoxCheck = Convert.ToBoolean(Request["CheckBoxChanged"]);
                if (temp == "true")
                {
                    t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                    d_row.LocationNo = locNo;
                    d_row.Shared = Sharing;
                    if (Convert.ToBoolean(dbEntity.SaveChanges()))
                    {
                        result = "Location Updated successfully.";
                    }
                    else
                    {
                        result = "Some error occured while Updating.";
                    }
                }
                else if (temp == "false")
                {
                    if (CheckBoxCheck)
                    {
                        List<t_LocationDetails> d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).ToList();
                        if (d_row.Count == 1)
                        {
                            d_row[0].Shared = Sharing;
                            if (Convert.ToBoolean(dbEntity.SaveChanges()))
                            {
                                result = "Location Updated successfully.";
                            }
                            else
                            {
                                result = "Some error occured while Updating.";
                            }
                        }
                        else
                        {
                            t_LocationDetails d_row1 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                            dbEntity.t_LocationDetails.Attach(d_row1);
                            dbEntity.t_LocationDetails.Remove(d_row1);
                            dbEntity.SaveChanges();
                            t_LocationDetails d_row2 = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate).Select(p => p).FirstOrDefault();
                            d_row1.Shared = Sharing;
                            if (Convert.ToBoolean(dbEntity.SaveChanges()))
                            {
                                result = "Location Updated successfully.";
                            }
                            else
                            {
                                result = "Some error occured while Updating.";
                            }
                        }
                    }
                    else
                    {
                        result = "Location ID Already Exists";
                    }
                    //
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ActionResult DeleteLocationDetails()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_LocationDetails tableObj = new t_LocationDetails();
                int Xcoordinate = Convert.ToInt32(Request["xCoord"]);
                int Ycoordinate = Convert.ToInt32(Request["yCoord"]);
                string locNo = Request["locationnumber"].ToString();
                    List<t_LocationDetails> d_row = dbEntity.t_LocationDetails.Where(p => p.CoOrdinateX1 == Xcoordinate && p.CoOrdinateY1 == Ycoordinate && p.LocationNo ==locNo).Select(p => p).ToList();
                    if (d_row.Count == 1)
                    {
                        dbEntity.t_LocationDetails.Attach(d_row[0]);
                        dbEntity.t_LocationDetails.Remove(d_row[0]);
                    }
                    else
                    {
                        dbEntity.t_LocationDetails.Attach(d_row[0]);
                        dbEntity.t_LocationDetails.Remove(d_row[0]);
                        dbEntity.SaveChanges();
                        dbEntity.t_LocationDetails.Attach(d_row[1]);
                        dbEntity.t_LocationDetails.Remove(d_row[1]);
                    }
                    if (Convert.ToBoolean(dbEntity.SaveChanges()))
                    {
                        result = "Location Deleted successfully.";
                    }
                    else
                    {
                        result = "Some error occured while Deleting.";
                    }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public ActionResult SaveLocationDetails()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            string result;
            string locNo =    Request["locationNumber"].ToString();
            int xcordinate =Convert.ToInt16( Request["xCoord"].ToString());
            int Ycordinate = Convert.ToInt16(Request["yCoord"]);
            string LocationName = Request["LocationName"].ToString();
            int MapId = Convert.ToInt16(Request["MapId"]);
            int LocationTypeId = Convert.ToInt16(Request["LocationTypeId"]);
            bool ActiveStatus =Convert.ToBoolean(Request["ActiveStatus"]);
            bool Sharing = Convert.ToBoolean(Request["Sharing"]);
            tableObj.LocationNo = locNo;
            tableObj.CoOrdinateX1 = xcordinate;
            tableObj.CoOrdinateY1 = Ycordinate;
            tableObj.LocationName = LocationName;
            tableObj.MapID = MapId;
            tableObj.LocationTypeID = LocationTypeId;
            tableObj.ActiveStatus = ActiveStatus;
            tableObj.Shared = Sharing;
            dbEntity.t_LocationDetails.Add(tableObj);
            if(Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Location added successfully.";
            }
            else
            {
                result = "Some error occured while saving.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetLocationDetails()
        {
            
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_UserLocationDetails> lstLocatoinMapping = new SeatModel().GetUserLocationDetails();
            List<t_UserDetails> lst = new SeatModel().GetUserDetails();

            var list = (from locDet in locationDetails
                         join locMap in lstLocatoinMapping on locDet.LocationID equals locMap.LocationID
                         join usr in lst on locMap.ComitID equals usr.ComitID
                         select new
                         {
                             LocationID = locDet.LocationID,
                             LocationNo = locDet.LocationNo,
                             CommitID =   locMap.ComitID,
                             XCoOrdinate = locDet.CoOrdinateX1,
                             YCoOrdinate = locDet.CoOrdinateY1,
                             FirstName = usr.FirstName,
                             LastName = usr.LastName,
                             Voip = locDet.VOIP,
                             Department = " ",
                             Team = " ",
                             EmailID = " ",
                         }).ToList();
                       

           /* var list = locationDetails.Select(p => new
             {
                 LocationNo = p.LocationNo,
                 CommitID =  lstLocatoinMapping.Where(l=>l.LocationID==p.LocationID).Select(l=>l.ComitID),
                 XCoOrdinate = p.CoOrdinateX1,
                 YCoOrdinate = p.CoOrdinateY1,
                 FirstName = lst.Where(u => u.ComitID == CommitID).Select(u => u.FirstName),
                 LastName = lst.Where(u => u.ComitID == "").Select(u => u.LastName),
                 Voip = p.VOIP,
                 Department = " ",
                 Team = " ",
                 EmailID = " ",
             }).ToList();*/
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SwapLocations()
        {
            string result= string.Empty;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_LocationDetails tableObj = new t_LocationDetails();
            string Com1ID = Request["Emp1ID"].ToString().ToUpper();
            string Com2ID = Request["Emp2ID"].ToString().ToUpper();
            string locNo1 = Request["Loc1"].ToString();
            string locNo2 = Request["Loc2"].ToString();
            t_LocationDetails d_row = dbEntity.t_LocationDetails.Where(p => p.CommitID == Com1ID && p.LocationNo == locNo2).Select(p => p).FirstOrDefault();
            t_LocationDetails d_row1 = dbEntity.t_LocationDetails.Where(p => p.CommitID == Com2ID && p.LocationNo == locNo1).Select(p => p).FirstOrDefault();
            int XCoordinate1 = Convert.ToInt32( d_row.CoOrdinateX1);
             int YCoordinate1 = Convert.ToInt32( d_row.CoOrdinateY1);
             int XCoordinate2 = Convert.ToInt32( d_row1.CoOrdinateX1);
             int YCoordinate2 = Convert.ToInt32( d_row1.CoOrdinateY1);
            //d_row.CoOrdinateX1 = XCoordinate2;
            //d_row.CoOrdinateY1 = YCoordinate2;
            d_row.CommitID = Com2ID;
            //d_row1.CoOrdinateX1 = XCoordinate1;
            //d_row1.CoOrdinateY1 = YCoordinate1;
            d_row1.CommitID = Com1ID;
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                result = "Location Swaped successfully.";
            }
            else
            {
                result = "Some error occured while Swaping.";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetCoordinateDetails()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_MapDetails> mapDetails = new SeatAllocationEntities().t_MapDetails.Select(p => p).ToList();
            // List<t_UserDetails> lst = new SeatModel().GetUserDetails();
            // string key = Request["Prathaban"].ToString();
            var list = locationDetails.Join(mapDetails, p => p.MapID, q => q.MapID, (p,q) => new
            {
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
                LocationNo = p.LocationNo,
                CommitId = p.CommitID,
                Shared = p.Shared,
                MapName = q.MapName
            }).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        /*
        [HttpPost]
        public ActionResult GetLocationDetails()
        {
            List<t_LocationDetails> locationDetails = new SeatModel().GetLocationDetails();
            List<t_UserDetails> lst = new SeatModel().GetUserDetails();
            var list = locationDetails.Select(p => new
            {
                LocationNo = p.LocationNo,
                CommitID = p.ComitID,
                XCoOrdinate = p.CoOrdinateX1,
                YCoOrdinate = p.CoOrdinateY1,
                FirstName = lst.Where(u => u.ComitID == p.ComitID).Select(u => u.FirstName),
                LastName = lst.Where(u => u.ComitID == p.ComitID).Select(u => u.LastName),
                Voip = p.VOIP,
                Department = " ",
                Team = " ",
                EmailID = " ",
            }).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }*/
        //
        // GET: /Seat/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Seat/Create

        public ActionResult Create()
        {
            return View();
        }
        public ActionResult Entry()
        {
            return View();
        }

        //
        // POST: /Seat/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Seat/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Seat/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Seat/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Seat/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        [HttpPost]
        public ActionResult GetEmployeesCollectionByManagerCommitID()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetHierarchy(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
                int obj1 = 0;
                return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
         public ActionResult GetEmployeesByLocationNumber()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetEmployees(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
               int obj1 = 0;
               return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet); 
        }
    
        [HttpPost]
        public ActionResult GetEmployeesByComitId()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetEmployees(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
               int obj1 = 0;
               return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet); 
        }
        [HttpPost]
        public ActionResult GetCommitIDbyLocationNumber()
        {
            string LocationNo = Request["LocationNo"].ToString().ToUpper(); ;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Where(u => u.LocationNo == LocationNo).Select(p => p.CommitID).Distinct().ToList(); ;
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalLocationNumbers()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Select(p => p.LocationNo).Distinct().ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalSharedSystems()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
           var d_row = dbEntity.t_LocationDetails.Where(u => u.Shared==true).Select(p => p.LocationNo).Distinct().ToList();
         

           return Json(d_row.Count(), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalEmployeesCommitId()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Where(u => u.CommitID != null).Select(p => p.CommitID).Distinct().ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetTotalSharedEmployees()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            var d_row = dbEntity.t_LocationDetails.Where(u => u.Shared == true && u.CommitID !=null).Select(p => p.LocationNo).Distinct().ToList();
            return Json(d_row.Count(), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetCommitIDByCoordinates()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            int Xcoordinate = Convert.ToInt32(Request["xCoord"]);
            int Ycoordinate = Convert.ToInt32(Request["yCoord"]);
            var d_row = dbEntity.t_LocationDetails.Where(u => u.CoOrdinateX1 == Xcoordinate && u.CoOrdinateY1 ==Ycoordinate).Select(p => p.CommitID).Distinct().ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetUseName()
        {
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            List<EmployeeDataContract> obj = objClient.GetHierarchy(Request["CommitId"].ToString()).ToList();
            if (obj.Count == 0)
            {
                int obj1 = 0;
                return Json(obj1, JsonRequestBehavior.AllowGet);
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
    }
}
