﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BNYM.SeatAllocation.Controllers
{
    public class FloorEntryController : Controller
    {
        //
        // GET: /FloorEntry/

        public ActionResult Index()
        {
            return View("FloorEntry");
        }

        //
        // GET: /FloorEntry/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /FloorEntry/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /FloorEntry/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /FloorEntry/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /FloorEntry/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /FloorEntry/Delete/5
 
        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /FloorEntry/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //ForMap
        public ActionResult ImageToByteArray()
        {
            string result = string.Empty;
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_MapDetails tableObj = new t_MapDetails();
            FileStream fs;
            string MapName = Request["MapName"].ToString();
            string Filename = Request["Filename"].ToString();
            fs = new FileStream(Filename, FileMode.Open, FileAccess.Read);
                      //a byte array to read the image   
            byte[] picbyte = new byte[fs.Length];
            fs.Read(picbyte, 0, System.Convert.ToInt32(fs.Length));
            fs.Close();
            tableObj.MapName = MapName;
            tableObj.MapImage = picbyte;
            dbEntity.t_MapDetails.Add(tableObj);
            if (Convert.ToBoolean(dbEntity.SaveChanges()))
            {
                string imageBase64 = Convert.ToBase64String(picbyte);
                string imageSrc = string.Format("data:image/jpg;base128,{0}", imageBase64);
                return Json(imageSrc
                  , JsonRequestBehavior.AllowGet);
            }
            else
            {
                result = "Some error occured while Adding.";
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ImageToByteArrayForDraggable()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            t_MapDetails tableObj = new t_MapDetails();
            FileStream fs;
            string MapName = Request["MapNameForDrag"].ToString();
            t_MapDetails d_row = dbEntity.t_MapDetails.Where(u => u.MapName == MapName).Select(p => p).FirstOrDefault();
            byte[] picbyte = new byte[200];
            picbyte= d_row.MapImage;
            string imageBase64 = Convert.ToBase64String(picbyte);
            string imageSrc = string.Format("data:image/jpg;base64,{0}", imageBase64);
            return Json(imageSrc
              , JsonRequestBehavior.AllowGet);
        }

        //
        //public Image ByteArrayToImage()
        //{
        //    SeatAllocationEntities dbEntity = new SeatAllocationEntities();
        //    t_MapDetails tableObj = new t_MapDetails();
        //    var d_row = dbEntity.t_MapDetails.Select(p => p.MapImage).ToList();
        //    MemoryStream mstream = new MemoryStream(d_row[0]);
        //    Image returnImage = Image.FromStream(mstream);
        //    return returnImage;
        //}
        [HttpPost]
        public ActionResult ByteArrayToImage()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            t_MapDetails tableobj = new t_MapDetails();
            var d_row = dbentity.t_MapDetails.Select(p => p.MapImage).ToList();
            string imageBase64 = Convert.ToBase64String(d_row[0]);
            string imageSrc = string.Format("data:image/jpg;base64,{0}", imageBase64);
            return Json(imageSrc
              , JsonRequestBehavior.AllowGet);


        }
           [HttpPost]
        public ActionResult CollectionOfMapName()
        {
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            t_MapDetails tableobj = new t_MapDetails();
            var d_row = dbentity.t_MapDetails.Select(p => p.MapName).ToList();
            return Json(d_row, JsonRequestBehavior.AllowGet);
        }
           [HttpPost]
           public ActionResult GetMapIdByMapName()
           {
               SeatAllocationEntities dbentity = new SeatAllocationEntities();
               t_MapDetails tableobj = new t_MapDetails();
               string MapName = Request["MapName"].ToString();
               var d_row = dbentity.t_MapDetails.Where(p => p.MapName == MapName).Select(p=>p.MapID).FirstOrDefault();
               return Json(d_row, JsonRequestBehavior.AllowGet);
           }
    }
}
