﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BNYM.SeatAllocation.AdminService;
using BNYM.SeatAllocation.Models;
using Newtonsoft.Json;

namespace BNYM.SeatAllocation.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/

        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /User/Details/5
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Details()   //int id
        {
            //if (Convert.ToBoolean(Session["LoginStatus"]) == true && (Session["Role"].ToString() == "iNautix Admin" || Session["Role"].ToString() == "BNYM Admin" || Session["Role"].ToString() == "Enterprise Admin"))
                return View();
            //else
                //return View("Error");
        }

        public ActionResult Reports()   //int id
        {
            return View();
        }

        //
        // GET: /User/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /User/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /User/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /User/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /User/Delete/5
 
        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /User/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        
        public ActionResult GetCollectionsOfRoles()
        {            
            SeatAllocationEntities dbentity = new SeatAllocationEntities();
            t_Roles tableobj = new t_Roles();
            var result = dbentity.t_Roles.Select(p => p).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetUserDetails()
        {            
            List<t_UserDetails> userDetails = new SeatModel().GetUserDetails();
            List<t_Roles> roles = new SeatAllocationEntities().t_Roles.Select(p => p).ToList();

            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();
            
            var list = userDetails.Join(roles, p => p.RoleID, q => q.RoleID, (p, q) => new
            {
                ComitID = p.ComitID,
                EmployeeName = string.Empty,
                ActiveStatus = p.ActiveStatus,
                RoleID = p.RoleID,
                LastUpdatedBy = p.LastUpdatedBy,
                LastUpdatedOn = p.LastUpdatedOn,
                RoleName = q.RoleName
            }).Where(z => z.ComitID != null).ToList();

            List<t_UserDetails_withName> listWithName = new List<t_UserDetails_withName>();
            for (int ictr = 0; ictr < list.Count; ictr++)
            {
                t_UserDetails_withName tmpObj = new t_UserDetails_withName();

                tmpObj.ComitID = list[ictr].ComitID;
                
                tmpObj.ActiveStatus = list[ictr].ActiveStatus;
                tmpObj.RoleID = list[ictr].RoleID;
                tmpObj.LastUpdatedBy = list[ictr].LastUpdatedBy;
                tmpObj.LastUpdatedOn = list[ictr].LastUpdatedOn;
                tmpObj.RoleName = list[ictr].RoleName;
                tmpObj.EmployeeName = "...";
                //try
                //{
                //    List<EmployeeDataContract> obj = objClient.GetHierarchy(list[ictr].ComitID.ToString()).ToList();
                //    if (obj.Count > 0)
                //        tmpObj.EmployeeName = obj[0].EmployeeName.ToString();
                    
                //}
                //catch (Exception e)
                //{
                //    tmpObj.EmployeeName = string.Empty;
                //}
                listWithName.Add(tmpObj);
            }

            return Json(listWithName, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetUserNames()
        {
            var currentEmployeeName = "";
            AdminService.AdminServiceClient objClient = new AdminService.AdminServiceClient();

            try
            {
                string ComitID = Request["ComitID"].Trim();
                if (ComitID != string.Empty)
                {
                    List<EmployeeDataContract> obj = objClient.GetHierarchy(ComitID.ToString()).ToList();
                    if (obj.Count > 0)
                        currentEmployeeName = obj[0].EmployeeName.ToString();
                }
            }
            catch (Exception e)
            {
                currentEmployeeName = string.Empty;
            }

            return Json(currentEmployeeName, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdateUserDetails()
        {
            try
            {
                string result = string.Empty;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_UserDetails tableObj = new t_UserDetails();

                string ComitID = Request["ComitID"];
                int RoleID = Convert.ToInt32(Request["RoleID"]);
                string LastUpdatedBy = Request["LastUpdatedBy"].ToString();
                
                t_UserDetails d_row = dbEntity.t_UserDetails.Where(p => p.ComitID == ComitID).Select(p => p).FirstOrDefault();
                d_row.ComitID = ComitID;
                d_row.RoleID = RoleID;
                d_row.LastUpdatedBy = LastUpdatedBy;
                d_row.LastUpdatedOn = DateTime.Now;
                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "Updated successfully.";
                }
                else
                {
                    result = "Update action has been failed.";
                }

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult AddUserDetails()
        {
            try
            {
                string result = string.Empty;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_UserDetails tableObj = new t_UserDetails();

                tableObj.ComitID = Request["ComitID"].ToString().ToUpper();
                tableObj.ActiveStatus = true;
                tableObj.RoleID = Convert.ToInt32(Request["RoleID"]);
                tableObj.LastUpdatedBy = Request["LastUpdatedBy"].ToString();
                tableObj.LastUpdatedOn = DateTime.Now;
                dbEntity.t_UserDetails.Add(tableObj);

                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "Added successfully.";
                }
                else
                {
                    result = "Add action has been failed.";
                }

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult DeleteUserDetails()
        {
            try
            {
                string result;
                SeatAllocationEntities dbEntity = new SeatAllocationEntities();
                t_UserDetails tableObj = new t_UserDetails();                
                string ComitID = Request["ComitID"].ToString();
                List<t_UserDetails> d_row = dbEntity.t_UserDetails.Where(p => p.ComitID == ComitID).Select(p => p).ToList();
                if (d_row.Count == 1)
                {
                    dbEntity.t_UserDetails.Attach(d_row[0]);
                    dbEntity.t_UserDetails.Remove(d_row[0]);
                }
                if (Convert.ToBoolean(dbEntity.SaveChanges()))
                {
                    result = "Deleted successfully.";
                }
                else
                {
                    result = "Delete action has been failed.";
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

    public class t_UserDetails_withName : t_UserDetails
    {
        public string EmployeeName { get; set; }
        public string RoleName { get; set; }
    }
}
