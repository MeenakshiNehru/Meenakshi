﻿


google.load('visualization', '1', { 'packages': ['geomap'] });
$(document).ready(function () {

    $(".chartHeading").hide();

    google.setOnLoadCallback(drawMap);



    //drawMap();
    // barChart(selectedVal);


   


    var currRegion = 'world';
    var geomap = null;
    var data = null;
    var geoDataMain = null;
    $.fn.center = function () {
        this.css("position", "absolute");

        this.css("top", ($(window).height() - this.height()) / 2 + $(window).scrollTop() + "px");
        this.css("left", ($(window).width() - this.width()) / 2 + $(window).scrollLeft() + "px");
        return this;
    }
    $(".chartHeading").hide();


    ///draw map 

    function drawMap()
    {

        $.support.cors = true;
        var geoTop = (($(window).height() - $('.pieLoading').height()) / 3 + $(window).scrollTop() + "px");

        $('.geoLoading').block({
            message: '<img class="loadingImg" src="../../Images/animated_loader.gif" style="position:absolute;top:' + geoTop + '" />',

            css: {
                border: 'none',
                background: 'none'

            },

            overlayCSS: {
                opacity: 4
            }
        });

        //var divisionData = {'division' : divisionId };
        $.ajax({
            crossDomain: true,
            cache: false,
            type: "post",
            dataType: 'json',
            url: '/home/GetCountByCity',
            success: function (jsonData) {
                drawGeoMapPositions(jsonData);
                $('.geoLoading').unblock();
            },
            error: function (jqXHR, textStatus, errorThrown) {

                alert("Service Error");
            }
        });
    }



    function drawGeoMapPositions(geoData) {

        geoDataMain = geoData;

        var map = new google.visualization.DataTable();
        map.addRows(geoData.length);  // length gives us the number of results in our returned data
        map.addColumn('string', 'country');
        map.addColumn('number', 'Count');

        $.each(geoData, function (i, v) {

            // set the values for both the name and the population
            map.setValue(i, 0, v.country);
            map.setValue(i, 1, v.Count);

        });
        //                 width: screen.width / 2.5,
        //                    height: screen.height / 2,

        var options = {
            width: 1000,
            height: 800,
            magnifyingGlass: { enabled: true, zoomFactor: 7.5 },
            displayMode: 'markers',
            colorAxis: { minValue: 3, colors: ['#FF0000', '#00FF00'] }
        };


        options['region'] = currRegion;
        options['colors'] = [0xFF8747, 0xFFB581, 0xc06000];
        var container = document.getElementById('map_canvas');
        if (geomap == null)
            geomap = new google.visualization.GeoChart(container);
        geomap.draw(map, options);
        $(".chartHeading").show();
    }


    //google.load("visualization", "1", { packages: ["corechart"] });


});



