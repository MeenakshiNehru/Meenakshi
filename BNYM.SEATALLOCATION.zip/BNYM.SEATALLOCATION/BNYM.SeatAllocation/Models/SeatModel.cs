﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BNYM.SeatAllocation.Models
{
    public class SeatModel
    {
        
        public List<t_LocationDetails> GetLocationDetails()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            return dbEntity.t_LocationDetails.Select(p => p).ToList();
        }
        public List<t_UserDetails> GetUserDetails()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            return dbEntity.t_UserDetails.Select(p => p).ToList();
        }        
        //public List<t_UserLocationDetails> GetUserLocationDetails()
        //{
        //    SeatAllocationEntities dbEntity = new SeatAllocationEntities();
        //    return dbEntity.t_UserLocationDetails.Select(p => p).ToList();        }
        public List<Coordinates> GetCoordinateDetails()
        {
            SeatAllocationEntities dbEntity = new SeatAllocationEntities();
            List<Coordinates> coordinates = dbEntity.t_LocationDetails.Select(p => new Coordinates { x = p.CoOrdinateX1, y = p.CoOrdinateY1, locationNumber = p.LocationNo }).Distinct().ToList();
            return coordinates;
        }

      
    }
    public class SwapLocation
    {
        public string ComitID { get; set; }
        public int LocationID { get; set; }
    }
    public class Coordinates
    { 
        public int? x { get; set; }
        public int? y { get; set; }
        public string locationNumber { get; set; }
    }
}