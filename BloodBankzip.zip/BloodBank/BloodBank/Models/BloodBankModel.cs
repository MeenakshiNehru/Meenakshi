﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BloodBank.Models
{
    public class BloodBankModel
    {



        public int BloodBankId { get; set; }



        [Display(Name = "Name")]
        [Required(ErrorMessage = "*")]
        public string BloodBankName { get; set; }


        [Display(Name = "Contact Number")]
        [Required(ErrorMessage = "*")]
        public string BloodBankContactNo { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "*")]
        public string BloodBankAddress { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "*")]
        public string BloodBankCity { get; set; }


        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "*")]

        public string BloodBankPincode { get; set; }


        [Display(Name = "Email")]
        [Required(ErrorMessage = "*")]
        public string BloodBankEmail { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "*")]
        public string Password { get; set; }


        [Display(Name = "SecurityQuestion")]
        [Required(ErrorMessage = "*")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "SecurityAnswer")]
        [Required(ErrorMessage = "*")]
        public string SecurityAnswer { get; set; }
     
    }
}