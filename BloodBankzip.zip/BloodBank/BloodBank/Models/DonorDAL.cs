﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;

namespace BloodBank.Models
{
    public class DonorDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool AddNewDonor(DonorModel model, string DonorEmail, string Password, string SecurityQuestion, string SecurityAnswer)
        {
            SqlCommand com_add = new SqlCommand("insert donor values(@dname,@dno,@dadd,@dcity,@dpin,@dage,@dgender,@dblood)", con);
            com_add.Parameters.AddWithValue("@dname", model.DonorName);
            com_add.Parameters.AddWithValue("@dno", model.DonorContactNo);
            com_add.Parameters.AddWithValue("@dadd", model.DonorAddress);
            com_add.Parameters.AddWithValue("@dcity", model.DonorCity);
            com_add.Parameters.AddWithValue("@dpin", model.DonorPincode);
            com_add.Parameters.AddWithValue("@dage", model.DonorAge);
            com_add.Parameters.AddWithValue("@dgender", model.DonorGender);
            com_add.Parameters.AddWithValue("@dblood", model.DonorBloodGroupId);
            con.Open();
            com_add.ExecuteNonQuery();


            SqlCommand com_donorid = new SqlCommand("Select @@identity", con);
            int donorid = Convert.ToInt32(com_donorid.ExecuteScalar());

            model.DonorID = donorid;
            con.Close();





            MembershipCreateStatus status;
            Membership.CreateUser(model.DonorID.ToString(), model.Password, model.DonorEmail, model.SecurityQuestion, model.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }


        }



        public List<CitiesModel> GetCity()
        {
            List<CitiesModel> list_city = new List<CitiesModel>();

            SqlCommand com_getcity = new SqlCommand("Select * from cities", con);
            con.Open();
            SqlDataReader dr = com_getcity.ExecuteReader();
            while (dr.Read())
            {
                CitiesModel c = new CitiesModel();
                c.CityId = dr.GetInt32(0);
                c.CityName = dr.GetString(1);
                list_city.Add(c);
            }
            con.Close();
            return list_city;
        }

        public List<BloodModel> GetBlood()
        {
            List<BloodModel> list_blood = new List<BloodModel>();
            SqlCommand com_getblood = new SqlCommand("select * from Blood", con);
            con.Open();
            SqlDataReader dr = com_getblood.ExecuteReader();
            while (dr.Read())
            {
                BloodModel c = new BloodModel();
                c.BloodId = dr.GetInt32(0);
                c.BloodName = dr.GetString(1);
                list_blood.Add(c);
            }
            con.Close();
            return list_blood;

        }

        public DonorModel ViewDonorProfile(int DonorId,string cityname,string bloodname)
        {
            DonorModel donor = new DonorModel();
            SqlCommand com_donorprofile = new SqlCommand("select * from donor where donorid=@donorid", con);
            com_donorprofile.Parameters.AddWithValue("@donorid", DonorId);
            con.Open();
            SqlDataReader dr = com_donorprofile.ExecuteReader();
            DonorModel m = new DonorModel();
            while(dr.Read())
            {
               
                m.DonorName = dr.GetString(1);
                m.DonorContactNo = dr.GetString(2);
                m.DonorAddress = dr.GetString(3);
                m.DonorCity = cityname;
                m.DonorPincode = dr.GetString(5);
                m.DonorAge = dr.GetInt32(6);
                m.DonorGender = dr.GetString(7);
                m.DonorBloodGroupId = bloodname;
                
            }
            con.Close();
            return m;
        }


        public string GetCityName(int cityid)
        {
            SqlCommand com_cityname = new SqlCommand("select cityname from cities where cityid=@cityid", con);
            com_cityname.Parameters.AddWithValue("@cityid", cityid);
            con.Open();
            string city=com_cityname.ExecuteScalar().ToString();
            con.Close();
            return city;

        }

        public int GetCityId(int DonorId)
        {
            SqlCommand com_cityid = new SqlCommand("select donorcity from donor where donorid=@id", con);
            com_cityid.Parameters.AddWithValue("@id", DonorId);
            con.Open();
            int cityid = Convert.ToInt32(com_cityid.ExecuteScalar()) ;
            con.Close();
            return cityid;
        }

        public int GetBloodId(int DonorId)
        {

            SqlCommand com_bloodid = new SqlCommand("select DonorBloodGroup from donor where donorid=@id", con);
            com_bloodid.Parameters.AddWithValue("@id", DonorId);
            con.Open();
            int bloodid = Convert.ToInt32(com_bloodid.ExecuteScalar());
            con.Close();
            return bloodid;
        }

        public string GetBloodName(int bloodid)
        {
            SqlCommand com_bloodname = new SqlCommand("select bloodname from blood where bloodid=@bloodid", con);
            com_bloodname.Parameters.AddWithValue("@bloodid", bloodid);
            con.Open();
            string blood = com_bloodname.ExecuteScalar().ToString();
            con.Close();
            return blood;

        }


        public List<DonationDetailsModel> ViewDonationDetails(int donorid)
        {
            List<DonationDetailsModel> list = new List<DonationDetailsModel>();
            SqlCommand com_donationdetails = new SqlCommand("select DonationDetails.DonationId,DonationDetails.DonationBloodAmount,blood.bloodname from DonationDetails join blood on DonationDetails.DonationBloodGroupId=blood.bloodid  where donorid=@id", con);
            com_donationdetails.Parameters.AddWithValue("@id", donorid);
            con.Open();
            SqlDataReader dr = com_donationdetails.ExecuteReader();
            while (dr.Read())
            {
                DonationDetailsModel d = new DonationDetailsModel();
                d.DonationId = dr.GetInt32(0);
                //d.DonorId = dr.GetInt32(1);
                d.DonationBloodGroup = dr.GetString(2);
                d.DonationBloodAmount = dr.GetString(1);
                list.Add(d);
            }

            con.Close();
            return list;

        }

        public List<DonorModel> SearchDonor(string DonorCity,string BloodGroup)
        {   
            List<DonorModel> list=new List<DonorModel>();
            SqlCommand com_searchdonor = new SqlCommand("select * from donor where donorcity=@city and donorbloodgroup=@blood" , con);
            com_searchdonor.Parameters.AddWithValue("@city", DonorCity);
            com_searchdonor.Parameters.AddWithValue("@blood", BloodGroup);
            con.Open();
            SqlDataReader dr = com_searchdonor.ExecuteReader();
            while(dr.Read())
            {
                DonorModel dal = new DonorModel();
                dal.DonorName = dr.GetString(1);
                dal.DonorContactNo = dr.GetString(2);
                dal.DonorAddress = dr.GetString(3);
                dal.DonorAge = dr.GetInt32(6);
                dal.DonorGender = dr.GetString(7);
                list.Add(dal);
            }
            con.Close();
            return list;
        }
    }
}