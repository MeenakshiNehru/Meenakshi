﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace BloodBank.Models
{
    public class BloodDetailsModel
    {
        [Display(Name="Packet ID")]
        public int BloodPacketId { get; set; }

       [Display(Name = "Blood ID")]
        public int BloodBankId { get; set; }

          [Display(Name = "Blood Group")]
        public string BloodGroup { get; set; }
          [Display(Name = "Amount")]
        public string BloodAmount { get; set; }
    }
}