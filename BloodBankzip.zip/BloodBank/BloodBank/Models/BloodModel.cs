﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BloodBank
{
    public class BloodModel
    {

        public int BloodId { get; set; }
        public string BloodName { get; set; }
    }
}