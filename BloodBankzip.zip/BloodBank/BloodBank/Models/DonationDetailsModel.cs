﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BloodBank.Models
{
    public class DonationDetailsModel
    {
        [Display(Name="Donation Id")]
        public int DonationId { get; set; }

        [Display(Name="Donor Id")]
        public int DonorId { get; set; }
        
        [Display(Name="Blood Group")]
        public string DonationBloodGroup { get; set; }

        [Display(Name="Amount")]
        [Required(ErrorMessage="Choose Amount")]
        public string DonationBloodAmount { get; set; }
        [Display(Name="Donation Date")]
        public DateTime DonationDate { get; set; }
        
        [Display(Name="Status")]
        public string AvailabilityStatus { get; set; }
    }
}