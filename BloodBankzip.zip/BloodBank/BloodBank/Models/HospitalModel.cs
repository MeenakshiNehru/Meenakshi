﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace BloodBank.Models
{
    public class HospitalModel
    {

        public int HospitalId { get; set; }



        [Display(Name = "Name")]
        [Required(ErrorMessage = "*")]
        public string HospitalName { get; set; }


        [Display(Name = "Contact Number")]
        [Required(ErrorMessage = "*")]
        public string HospitalContactNo { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "*")]
        public string HospitalAddress { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "*")]
        public string HospitalCity { get; set; }


        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "*")]

        public string HospitalPincode { get; set; }


        [Display(Name = "Email")]
        [Required(ErrorMessage = "*")]
        public string HospitalEmail { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "*")]
        public string Password { get; set; }


        [Display(Name = "SecurityQuestion")]
        [Required(ErrorMessage = "*")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "SecurityAnswer")]
        [Required(ErrorMessage = "*")]
        public string SecurityAnswer { get; set; }
    }
}