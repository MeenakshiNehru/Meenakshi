﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BloodBank
{
    public class DonorModel
    {


        public int DonorID { get; set; }


        [Display(Name = "Name")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Min 5 Chars")]
        [RegularExpression("[a-zA-Z]+$", ErrorMessage = ("Invalid Name"))]
        [Required(ErrorMessage = "Enter Name")]
        public string DonorName { get; set; }

        [Display(Name = "Contact Number")]
        [RegularExpression("[0-9]+$", ErrorMessage = ("Invalid Mobile Number"))]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Invalid Contact Number")]
        [Required(ErrorMessage = "Enter Contact Number")]
        public string DonorContactNo { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address")]
        public string DonorAddress { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Choose a City")]
        public string DonorCity { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode")]
        public string DonorPincode { get; set; }

        [Display(Name = "Age")]
        
        [Required(ErrorMessage = "Enter Age")]
        [Range(18, 60, ErrorMessage = "Enter Valid Age")]
        public int DonorAge { get; set; }


        [Display(Name = "Gender")]
        [Required(ErrorMessage = "Choose a Gender")]
        public string DonorGender { get; set; }


        [Display(Name = "Blood Group")]
        [Required(ErrorMessage = "Choose Blood Group")]
        public string DonorBloodGroupId { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email Id")]
        [EmailAddress(ErrorMessage="Enter valid EmailId")]
        public string DonorEmail { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }


        [Display(Name = "SecurityQuestion")]
        [Required(ErrorMessage = "Enter Security Question")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "SecurityAnswer")]
        [Required(ErrorMessage = "Enter Security Question")]
        public string SecurityAnswer { get; set; }
     
    }
}