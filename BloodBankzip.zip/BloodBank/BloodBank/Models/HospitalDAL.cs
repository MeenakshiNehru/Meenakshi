﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
namespace BloodBank.Models
{
    public class HospitalDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool AddNewhospital(HospitalModel model, string HospitalEmail, string Password, string SecurityQuestion, string SecurityAnswer)
        {

            SqlCommand com_hospital = new SqlCommand("insert hospital values(@name,@contactno,@add,@city,@pin)", con);
            com_hospital.Parameters.AddWithValue("@name", model.HospitalName);
            com_hospital.Parameters.AddWithValue("@contactno", model.HospitalContactNo);
            com_hospital.Parameters.AddWithValue("@add", model.HospitalAddress);
            com_hospital.Parameters.AddWithValue("@city", model.HospitalCity);
            com_hospital.Parameters.AddWithValue("@pin", model.HospitalPincode);
            con.Open();
            com_hospital.ExecuteNonQuery();
            SqlCommand com_hspid = new SqlCommand("select @@identity", con);
            int hospitalid = Convert.ToInt32(com_hspid.ExecuteScalar());
            model.HospitalId = hospitalid;
            con.Close();

            MembershipCreateStatus status;
            Membership.CreateUser(model.HospitalId.ToString(), model.Password, model.HospitalEmail, model.SecurityQuestion, model.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }


        }


        public HospitalModel ViewHospitalProfile(int HospitalId,string cityname)
        {
            SqlCommand com_profile = new SqlCommand("select * from hospital where hospitalid=@id", con);
            com_profile.Parameters.AddWithValue("@id", HospitalId);
            con.Open();
            SqlDataReader dr = com_profile.ExecuteReader();
            HospitalModel mod = new HospitalModel();
            while(dr.Read())
            {
                mod.HospitalName = dr.GetString(1);
                mod.HospitalContactNo = dr.GetString(2);
                mod.HospitalAddress = dr.GetString(3);
                mod.HospitalCity = cityname;
                mod.HospitalPincode = dr.GetString(5);
            }
            con.Close();
            return mod;
        }

        public string GetCityName(int cityid)
        {
            SqlCommand com_cityname = new SqlCommand("select cityname from cities where cityid=@cityid", con);
            com_cityname.Parameters.AddWithValue("@cityid", cityid);
            con.Open();
            string city = com_cityname.ExecuteScalar().ToString();
            con.Close();
            return city;

        }

        public int GetCityId(int hospitalid)
        {
            SqlCommand com_cityid = new SqlCommand("select HospitalCity from Hospital where HospitalId=@id", con);
            com_cityid.Parameters.AddWithValue("@id", hospitalid);
            con.Open();
            int cityid = Convert.ToInt32(com_cityid.ExecuteScalar());
            con.Close();
            return cityid;
        }

        public List<RequestDetailsModel> ViewHospitalRequestDetails(int hospitalid)
        {
            List<RequestDetailsModel> list = new List<RequestDetailsModel>();
            SqlCommand com_details = new SqlCommand("select RequestDetails.RequestId,RequestDetails.RequestBloodAmount,blood.bloodname from RequestDetails join blood on RequestDetails.requestBloodGroupId=blood.bloodid  where RequestHospitalId=@id", con);
            com_details.Parameters.AddWithValue("@id", hospitalid);
            con.Open();
            SqlDataReader dr = com_details.ExecuteReader();
            while (dr.Read())
            {
                RequestDetailsModel d = new RequestDetailsModel();
                d.RequestId= dr.GetInt32(0);
                //d.DonorId = dr.GetInt32(1);
                d.RequestBloodGroup = dr.GetString(2);
                d.RequestBloodAmount = dr.GetString(1);
                list.Add(d);
            }

            con.Close();
            return list;

        }
    }
}