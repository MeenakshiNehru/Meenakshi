﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Security;
using System.Data.SqlClient;
namespace BloodBank.Models
{
    public class BloodBankDAL
    {


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


        public bool AddNewBloodbank(BloodBankModel model, string BloodBankEmail, string Password, string SecurityQuestion, string SecurityAnswer)
        {

            SqlCommand com_bloodbank = new SqlCommand("insert bloodbank values(@name,@contactno,@add,@city,@pin)", con);
            com_bloodbank.Parameters.AddWithValue("@name", model.BloodBankName);
            com_bloodbank.Parameters.AddWithValue("@contactno", model.BloodBankContactNo);
            com_bloodbank.Parameters.AddWithValue("@add", model.BloodBankAddress);
            com_bloodbank.Parameters.AddWithValue("@city", model.BloodBankCity);
            com_bloodbank.Parameters.AddWithValue("@pin", model.BloodBankPincode);
            con.Open();
            com_bloodbank.ExecuteNonQuery();
            SqlCommand com_bloodbankid = new SqlCommand("select @@identity", con);
            int bloodbankid = Convert.ToInt32(com_bloodbankid.ExecuteScalar());
            model.BloodBankId = bloodbankid;
            con.Close();

            MembershipCreateStatus status;
            Membership.CreateUser(model.BloodBankId.ToString(), model.Password, model.BloodBankEmail, model.SecurityQuestion, model.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        public BloodBankModel ViewBloodBankProfile(int BloodBankId,string cityname)
        {
            SqlCommand com_profile = new SqlCommand("select * from bloodbank where bloodbankid=@id", con);
            com_profile.Parameters.AddWithValue("@id", BloodBankId);
            con.Open();
            SqlDataReader dr = com_profile.ExecuteReader();
            BloodBankModel mod = new BloodBankModel();
            while (dr.Read())
            {
                mod.BloodBankName = dr.GetString(1);
                mod.BloodBankContactNo = dr.GetString(2);
                mod.BloodBankAddress = dr.GetString(3);
                mod.BloodBankCity = cityname;
                mod.BloodBankPincode = dr.GetString(5);
            }
            con.Close();
            return mod;
        }

        public bool AddBlood(BloodDetailsModel d)
        {
            SqlCommand com_addblood = new SqlCommand("insert blooddetails values(@bloodbankid,@bloodgroup,@amount)", con);
            com_addblood.Parameters.AddWithValue("@bloodbankid", d.BloodBankId);
            com_addblood.Parameters.AddWithValue("@bloodgroup", d.BloodGroup);
            com_addblood.Parameters.AddWithValue("@amount", d.BloodAmount);
            con.Open();
            com_addblood.ExecuteNonQuery();
            con.Close();
            return true;

        }
        public bool MakeRequest(RequestDetailsModel mod)
        {
            SqlCommand com_addreq = new SqlCommand("insert RequestDetails values(@hospitalid,@bloodgroup,@amount,getdate(),'Pending')", con);
            com_addreq.Parameters.AddWithValue("@hospitalid", mod.RequestHospitalId);
            com_addreq.Parameters.AddWithValue("@bloodgroup", mod.RequestBloodGroup);
            com_addreq.Parameters.AddWithValue("@amount", mod.RequestBloodAmount);
            con.Open();
            com_addreq.ExecuteNonQuery();
            con.Close();
            return true;
        }

        public List<RequestDetailsModel> ViewRequest()
        {
            List<RequestDetailsModel> list = new List<RequestDetailsModel>();
            SqlCommand com_viewrequest = new SqlCommand("select RequestDetails.RequestId,RequestDetails.RequestBloodAmount,RequestDetails.RequestDetails,blood.BloodName from blood join requestdetails on requestdetails.requestBloodGroupId=blood.bloodid  where RequestDetails='Pending'", con);
            con.Open();
            SqlDataReader dr = com_viewrequest.ExecuteReader();
            while (dr.Read())
            {
                RequestDetailsModel m = new RequestDetailsModel();
                m.RequestId = dr.GetInt32(0);
                // m.RequestHospitalId = dr.GetInt32(1);
                m.RequestBloodGroup = dr.GetString(3);
                m.RequestBloodAmount = dr.GetString(1);
                m.RequestStatus = dr.GetString(2);
                //  m.RequestDate = dr.GetDateTime(3).ToString();


                list.Add(m);
            }
            con.Close();
            return list;
        }

        public bool MakeNewDonation(DonationDetailsModel d)
        {

            SqlCommand com_donorid = new SqlCommand("select DonorBloodGroup from donor where donorid=@did", con);
            com_donorid.Parameters.AddWithValue("@did", d.DonorId);
            con.Open();
            int bloodgroupid = Convert.ToInt32(com_donorid.ExecuteScalar());

            SqlCommand com_donation = new SqlCommand("insert DonationDetails values(@DonorId,@bloodgroup,@amount,getdate(),'Available')", con);
            com_donation.Parameters.AddWithValue("@DonorId", d.DonorId);
            com_donation.Parameters.AddWithValue("@bloodgroup", bloodgroupid);
            com_donation.Parameters.AddWithValue("@amount", d.DonationBloodAmount);

            com_donation.ExecuteNonQuery();
            con.Close();
            return true;
        }

        public List<DonationDetailsModel> ViewDonation()
        {
            List<DonationDetailsModel> list = new List<DonationDetailsModel>();
            SqlCommand com_viewdonation = new SqlCommand("select DonationDetails.DonationId,DonationDetails.DonationBloodAmount ,DonationDetails.AvailabityStatus,blood.BloodName from blood join donationdetails on DonationDetails.DonationBloodGroupId=blood.bloodid ", con);
            con.Open();
            SqlDataReader dr = com_viewdonation.ExecuteReader();
            while (dr.Read())
            {
                DonationDetailsModel d = new DonationDetailsModel();
                d.DonationId = dr.GetInt32(0);
                d.DonationBloodGroup = dr.GetString(3);
                d.DonationBloodAmount = dr.GetString(1);
                d.AvailabilityStatus = dr.GetString(2);
                list.Add(d);

            }
            con.Close();
            return list;
        }



        public string GetBloodGroup(int bloodid)
        {
            SqlCommand com_name = new SqlCommand("select bloodname from blood where bloodid=@id", con);
            com_name.Parameters.AddWithValue("@id", bloodid);
            con.Open();
            string BloodGroup = com_name.ExecuteScalar().ToString();

            con.Close();
            return BloodGroup;
        }

        public string GetHospital(int hospitalid)
        {
            SqlCommand com_name = new SqlCommand("select hospitalname from hospital where hospitalid=@id", con);
            com_name.Parameters.AddWithValue("@id", hospitalid);
            con.Open();
            string Hosp = com_name.ExecuteScalar().ToString();
            con.Close();
            return Hosp;
        }

        public int GetHId(int id)
        {
            SqlCommand com = new SqlCommand("select RequestHospitalId from RequestDetails where RequestId=@id", con);
            com.Parameters.AddWithValue("@id", id);
            con.Open();
            int Hid = Convert.ToInt32(com.ExecuteScalar());
            con.Close();
            return Hid;
        }
        public int GetBID(int id)
        {
            SqlCommand com = new SqlCommand("select requestBloodGroupId from RequestDetails where RequestId=@id", con);
            com.Parameters.AddWithValue("@id", id);
            con.Open();
            int Hid = Convert.ToInt32(com.ExecuteScalar());
            con.Close();
            return Hid;
        }

        public string GetAmount(int id)
        {
            SqlCommand com = new SqlCommand("select RequestBloodAmount from RequestDetails where RequestId=@id", con);
            com.Parameters.AddWithValue("@id", id);
            con.Open();
            string amt = com.ExecuteScalar().ToString();
            con.Close();
            return amt;

        }


        public List<DonationDetailsModel> ShowAvailability(string b)
        {
            List<DonationDetailsModel> list = new List<DonationDetailsModel>();
            SqlCommand com = new SqlCommand("select DonationDetails.DonationId,DonationDetails.DonationBloodAmount,blood.bloodname from DonationDetails join blood on DonationDetails.DonationBloodGroupId=blood.bloodid  where AvailabityStatus='Available' and DonationBloodGroupId in(select BloodId from blood where bloodname=@name)  ", con);
            com.Parameters.AddWithValue("@name", b);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            while (dr.Read())
            {
                DonationDetailsModel d = new DonationDetailsModel();
                d.DonationId = dr.GetInt32(0);
                //d.DonorId = dr.GetInt32(1);
                d.DonationBloodGroup = dr.GetString(2);
                d.DonationBloodAmount = dr.GetString(1);
                list.Add(d);
            }

            con.Close();
            return list;
        }

        public bool Allocation(int id, int reqid)
        {
            SqlCommand com_chngstatus = new SqlCommand("update DonationDetails set AvailabityStatus='UnAvailable' where DonationId=@id", con);

            com_chngstatus.Parameters.AddWithValue("@id", id);
            SqlCommand com_chgreqstatus = new SqlCommand("update RequestDetails set RequestDetails='Done' where RequestId=@reqid", con);
            com_chgreqstatus.Parameters.AddWithValue("@reqid", reqid);
            con.Open();
            com_chngstatus.ExecuteNonQuery();
            com_chgreqstatus.ExecuteNonQuery();
            con.Close();
            return true;
        }
        public int AddAllocation(int donationid, int requestid)
        {
            SqlCommand com_blood = new SqlCommand("select requestBloodGroupId from RequestDetails where RequestId=@reqid", con);
            com_blood.Parameters.AddWithValue("@reqid", requestid);
            con.Open();
            int blood = Convert.ToInt32(com_blood.ExecuteScalar());
            SqlCommand com_amt = new SqlCommand("select RequestBloodAmount from RequestDetails where RequestId=@reqid", con);
            com_amt.Parameters.AddWithValue("@reqid", requestid);
            int amount = Convert.ToInt32(com_amt.ExecuteScalar());
            SqlCommand com_add = new SqlCommand("insert Allocation values(@donationid,@RequestId,@BloodGroupId,@BloodAmount)", con);
            com_add.Parameters.AddWithValue("@donationid", donationid);
            com_add.Parameters.AddWithValue("@RequestId", requestid);
            com_add.Parameters.AddWithValue("@BloodGroupId", blood);
            com_add.Parameters.AddWithValue("@BloodAmount", amount);
          
            com_add.ExecuteNonQuery();
            SqlCommand com_allocationid =new  SqlCommand("Select @@identity", con);
            int allocationid = Convert.ToInt32(com_allocationid.ExecuteScalar());
            con.Close();
            return allocationid;
        }

        public string GetDonorDetails(int id)
        {
            SqlCommand com_Donor = new SqlCommand("select DonorName from Donor where DonorId in (select DonorId from DonationDetails Where donationid in(select DonationId from Allocation Where AllocationId=@id))", con);
            com_Donor.Parameters.AddWithValue("@id", id);
            con.Open();
            string donor =Convert.ToString( com_Donor.ExecuteScalar());
            con.Close();
            return donor;
        }
        public string GetHospitalDetails(int id)
        {
            SqlCommand com_hospital = new SqlCommand("select HospitalName from hospital where hospitalId in (select RequesthospitalId from RequestDetails Where Requestid in(select Requestid from Allocation Where AllocationId=@id))  ", con);
            com_hospital.Parameters.AddWithValue("@id", id);
            con.Open();
            string hospital = Convert.ToString(com_hospital.ExecuteScalar());
            con.Close();
            return hospital;
        }

        public string GetCityName(int cityid)
        {
            SqlCommand com_cityname = new SqlCommand("select cityname from cities where cityid=@cityid", con);
            com_cityname.Parameters.AddWithValue("@cityid", cityid);
            con.Open();
            string city = com_cityname.ExecuteScalar().ToString();
            con.Close();
            return city;

        }

        public int GetCityId(int BloodBankId)
        {
            SqlCommand com_cityid = new SqlCommand("select BloodBankCity from BloodBank where BloodBankId=@id", con);
            com_cityid.Parameters.AddWithValue("@id", BloodBankId);
            con.Open();
            int cityid = Convert.ToInt32(com_cityid.ExecuteScalar());
            con.Close();
            return cityid;
        }

    }
}