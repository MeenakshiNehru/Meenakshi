﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BloodBank.Models
{
    public class RequestDetailsModel
    { 
        [Display(Name="Request Id")]
        public int RequestId { get; set; }
        [Display(Name="Hospital Id")]
        public int RequestHospitalId { get; set; }

        [Display(Name="Blood Group")]
        [Required(ErrorMessage=("Choose blood group"))]
        public string RequestBloodGroup { get; set; }

        [Display(Name="Amount")]
        [Required(ErrorMessage = "Choose Amount")]
        public string RequestBloodAmount { get; set; }

        [Display(Name="Request Date")]
        public DateTime RequestDate { get; set; }

        [Display(Name="Status")]
        public string RequestStatus { get; set; }
    }
}