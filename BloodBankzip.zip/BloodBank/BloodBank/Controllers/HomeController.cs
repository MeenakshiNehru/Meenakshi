﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.ComponentModel.DataAnnotations;
using BloodBank.Models;
namespace BloodBank.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DonorSuccess()
        {
            return View();
        }
        public ActionResult HospitalSuccess()
        {
            return View();
        }

        public ActionResult BloodBankSuccess()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult DonorLogin()
        {
           
      
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult DonorLogin(int DonorID, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(DonorID.ToString(), Password))
            {
                FormsAuthentication.SetAuthCookie(DonorID.ToString(), rememberme);

                return RedirectToAction("DonorSuccess", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid UserId or Password";
                return View();
            }
        }



        [AllowAnonymous]
        public ActionResult NewDonor()
        {
            List<SelectListItem> Gender = new List<SelectListItem>();
            Gender.Add(new SelectListItem { Text = "Male", Value = "Male" });
            Gender.Add(new SelectListItem { Text = "Female", Value = "Female" });
            ViewBag.Gender = Gender;

            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;

            List<SelectListItem> blood_list = new List<SelectListItem>();
            List<BloodModel> blood = dal.GetBlood();
            foreach (BloodModel item in blood)
            {
                blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
            }
            ViewBag.blood = blood_list;

            List<SelectListItem> Question = new List<SelectListItem>();
            Question.Add(new SelectListItem { Text = "What was your childhood nickname?", Value = "What was your childhood nickname??" });
            Question.Add(new SelectListItem { Text = "What is your favorite team?", Value = "What is your favorite team?" });
            Question.Add(new SelectListItem { Text = "In what town was your first job?", Value = "In what town was your first job?" });
            Question.Add(new SelectListItem { Text = "What primary school did you attend?", Value = "What primary school did you attend?" });
            Question.Add(new SelectListItem { Text = "What is your favorite color?", Value = "What is your favorite color?" });
            Question.Add(new SelectListItem { Text = "Where did you spend your honeymoon?", Value = "Where did you spend your honeymoon?" });
            Question.Add(new SelectListItem { Text = "What is your dream job?", Value = "What is your dream job?" });
            
            ViewBag.securityquestion = Question;


            return View();


        }

        [AllowAnonymous]
        [HttpPost]

        public ActionResult NewDonor(DonorModel detail, string DonorEmail, string Password, string SecurityQuestion, string SecurityAnswer)
        {
            List<SelectListItem> Gender = new List<SelectListItem>();
            Gender.Add(new SelectListItem { Text = "Male", Value = "Male" });
            Gender.Add(new SelectListItem { Text = "Female", Value = "Female" });
            ViewBag.Gender = Gender;
            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;

            List<SelectListItem> blood_list = new List<SelectListItem>();
            List<BloodModel> blood = dal.GetBlood();
            foreach (BloodModel item in blood)
            {
                blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
            }
            ViewBag.blood = blood_list;
            List<SelectListItem> Question = new List<SelectListItem>();
            Question.Add(new SelectListItem { Text = "What was your childhood nickname?", Value = "What was your childhood nickname??" });
            Question.Add(new SelectListItem { Text = "What is your favorite team?", Value = "What is your favorite team?" });
            Question.Add(new SelectListItem { Text = "In what town was your first job?", Value = "In what town was your first job?" });
            Question.Add(new SelectListItem { Text = "What primary school did you attend?", Value = "What primary school did you attend?" });
            Question.Add(new SelectListItem { Text = "What is your favorite color?", Value = "What is your favorite color?" });
            Question.Add(new SelectListItem { Text = "Where did you spend your honeymoon?", Value = "Where did you spend your honeymoon?" });
            Question.Add(new SelectListItem { Text = "What is your dream job?", Value = "What is your dream job?" });
            ViewBag.securityquestion = Question;



           // DonorDAL dal = new DonorDAL();

            if (dal.AddNewDonor(detail, Password, DonorEmail, SecurityQuestion, SecurityAnswer))
            {


                ViewBag.msg = "Registered,Your Donor Id is:" + detail.DonorID;
                ModelState.Clear();
                return View();
            }

            else
            {
                ViewBag.msg = "Registration Failed";
                return View();

            }
        }

        [AllowAnonymous]
        public ActionResult BloodBankLogin()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult BloodBankLogin(int BloodBankId, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(BloodBankId.ToString(), Password))
            {
                FormsAuthentication.SetAuthCookie(BloodBankId.ToString(), rememberme);

                return RedirectToAction("BloodBankSuccess", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid UserId or Password";
                return View();
            }
        }


        public ActionResult BloodBankLogout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
           
        }
        public ActionResult HospitalLogout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");

        }


        public ActionResult DonorLogout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");

        }
        [AllowAnonymous]
        public ActionResult NewBloodBank()
        {
            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;
            List<SelectListItem> Question = new List<SelectListItem>();
            Question.Add(new SelectListItem { Text = "What was your childhood nickname?", Value = "What was your childhood nickname??" });
            Question.Add(new SelectListItem { Text = "What is your favorite team?", Value = "What is your favorite team?" });
            Question.Add(new SelectListItem { Text = "In what town was your first job?", Value = "In what town was your first job?" });
            Question.Add(new SelectListItem { Text = "What primary school did you attend?", Value = "What primary school did you attend?" });
            Question.Add(new SelectListItem { Text = "What is your favorite color?", Value = "What is your favorite color?" });
            Question.Add(new SelectListItem { Text = "Where did you spend your honeymoon?", Value = "Where did you spend your honeymoon?" });
            Question.Add(new SelectListItem { Text = "What is your dream job?", Value = "What is your dream job?" });
            ViewBag.securityquestion = Question;


            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult NewBloodBank(BloodBankModel m, string BloodBankEmail, string Password, string SecurityQuestion, string SecurityAnswer)
        {

            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;
            List<SelectListItem> Question = new List<SelectListItem>();
            Question.Add(new SelectListItem { Text = "What was your childhood nickname?", Value = "What was your childhood nickname??" });
            Question.Add(new SelectListItem { Text = "What is your favorite team?", Value = "What is your favorite team?" });
            Question.Add(new SelectListItem { Text = "In what town was your first job?", Value = "In what town was your first job?" });
            Question.Add(new SelectListItem { Text = "What primary school did you attend?", Value = "What primary school did you attend?" });
            Question.Add(new SelectListItem { Text = "What is your favorite color?", Value = "What is your favorite color?" });
            Question.Add(new SelectListItem { Text = "Where did you spend your honeymoon?", Value = "Where did you spend your honeymoon?" });
            Question.Add(new SelectListItem { Text = "What is your dream job?", Value = "What is your dream job?" });
            ViewBag.securityquestion = Question;



            BloodBankDAL d = new BloodBankDAL();

            if (d.AddNewBloodbank(m, Password, BloodBankEmail, SecurityQuestion, SecurityAnswer))
            {


                ViewBag.msg = "Registered,Your BloodBank Id is:" + m.BloodBankId;
                ModelState.Clear();
                return View();
            }

            else
            {
                ViewBag.msg = "Registration Failed";
                return View();
            }
        }


        [AllowAnonymous]
        public ActionResult HospitalLogin()
        {
            return View();
        }

        [HttpPost]

        [AllowAnonymous]

        public ActionResult HospitalLogin(int HospitalId, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(HospitalId.ToString(), Password))
            {
                FormsAuthentication.SetAuthCookie(HospitalId.ToString(), rememberme);

                return RedirectToAction("HospitalSuccess", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid UserId or Password";

                return View();
            }
        }

        public ActionResult NewHospital()
        {
            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;
            List<SelectListItem> Question = new List<SelectListItem>();
            Question.Add(new SelectListItem { Text = "What was your childhood nickname?", Value = "What was your childhood nickname??" });
            Question.Add(new SelectListItem { Text = "What is your favorite team?", Value = "What is your favorite team?" });
            Question.Add(new SelectListItem { Text = "In what town was your first job?", Value = "In what town was your first job?" });
            Question.Add(new SelectListItem { Text = "What primary school did you attend?", Value = "What primary school did you attend?" });
            Question.Add(new SelectListItem { Text = "What is your favorite color?", Value = "What is your favorite color?" });
            Question.Add(new SelectListItem { Text = "Where did you spend your honeymoon?", Value = "Where did you spend your honeymoon?" });
            Question.Add(new SelectListItem { Text = "What is your dream job?", Value = "What is your dream job?" });
            ViewBag.securityquestion = Question;
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult NewHospital(HospitalModel m, string HospitalEmail, string Password, string SecurityQuestion, string SecurityAnswer)
        {

            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;
            List<SelectListItem> Question = new List<SelectListItem>();
            Question.Add(new SelectListItem { Text = "What was your childhood nickname?", Value = "What was your childhood nickname??" });
            Question.Add(new SelectListItem { Text = "What is your favorite team?", Value = "What is your favorite team?" });
            Question.Add(new SelectListItem { Text = "In what town was your first job?", Value = "In what town was your first job?" });
            Question.Add(new SelectListItem { Text = "What primary school did you attend?", Value = "What primary school did you attend?" });
            Question.Add(new SelectListItem { Text = "What is your favorite color?", Value = "What is your favorite color?" });
            Question.Add(new SelectListItem { Text = "Where did you spend your honeymoon?", Value = "Where did you spend your honeymoon?" });
            Question.Add(new SelectListItem { Text = "What is your dream job?", Value = "What is your dream job?" });
            ViewBag.securityquestion = Question;


            HospitalDAL d = new HospitalDAL();

            if (d.AddNewhospital(m, Password, HospitalEmail, SecurityQuestion, SecurityAnswer))
            {


                ViewBag.msg = "Registered,Your Hospital Id is:" + m.HospitalId;
                ModelState.Clear();
                return View();
            }

            else
            {
                ViewBag.msg = "Registration Failed";
                return View();
            }
        }
    
    
      [Authorize]
      public ActionResult ViewDonorProfile()
        {
            int DonorId = Convert.ToInt32(User.Identity.Name);
            DonorDAL dal = new DonorDAL();
            int cityid = dal.GetCityId(DonorId);
            string cityname = dal.GetCityName(cityid);
            int bloodid = dal.GetBloodId(DonorId);
            string blood = dal.GetBloodName(bloodid);
            DonorModel m = dal.ViewDonorProfile(DonorId,cityname,blood);
           
            return View(m);
        }

      [Authorize]
      public ActionResult ViewHospitalProfile()
      {
          int HospitalId = Convert.ToInt32(User.Identity.Name);
          HospitalDAL d = new HospitalDAL();
          int cityid = d.GetCityId(HospitalId);
          string cityname = d.GetCityName(cityid);
          
      

          HospitalModel m = d.ViewHospitalProfile(HospitalId,cityname);

          return View(m);
      }
        [Authorize]
     public ActionResult ViewBloodBankProfile()
      {
          int BloodBankId = Convert.ToInt32(User.Identity.Name);
          BloodBankDAL dal = new BloodBankDAL();
          int cityid = dal.GetCityId(BloodBankId);
          string cityname = dal.GetCityName(cityid);
          
          BloodBankModel m = dal.ViewBloodBankProfile(BloodBankId,cityname);
          return View(m);

      }

    public ActionResult AddBloodDetails()

    {

        List<SelectListItem> Amount = new List<SelectListItem>();
        Amount.Add(new SelectListItem { Text = "100", Value = "100" });
        Amount.Add(new SelectListItem { Text = "200", Value = "200" });
        Amount.Add(new SelectListItem { Text = "300", Value = "300" });
        ViewBag.Amount = Amount;
        DonorDAL dal = new DonorDAL();
       List<SelectListItem> blood_list = new List<SelectListItem>();
       List<BloodModel> blood = dal.GetBlood();
       foreach (BloodModel item in blood)
       {
           blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
       }
       ViewBag.blood = blood_list;

        return View();
    }
    [HttpPost]
    public ActionResult AddBloodDetails(BloodDetailsModel m)
  {
      List<SelectListItem> Amount = new List<SelectListItem>();
      Amount.Add(new SelectListItem { Text = "100", Value = "100" });
      Amount.Add(new SelectListItem { Text = "200", Value = "200" });
      Amount.Add(new SelectListItem { Text = "300", Value = "300" });
      ViewBag.Amount = Amount;


      DonorDAL dal = new DonorDAL();
      List<SelectListItem> blood_list = new List<SelectListItem>();
      List<BloodModel> blood = dal.GetBlood();
      foreach (BloodModel item in blood)
      {
          blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
      }
      ViewBag.blood = blood_list;
      
      m.BloodBankId =Convert.ToInt32( User.Identity.Name);
      BloodBankDAL l = new BloodBankDAL();
      l.AddBlood(m);
      ViewBag.msg = "Blood Details Added";
      return View();
  }
   
    public ActionResult MakeNewRequest()
   {

       List<SelectListItem> Amount = new List<SelectListItem>();
       Amount.Add(new SelectListItem { Text = "100 ml", Value = "100" });
       Amount.Add(new SelectListItem { Text = "200 ml", Value = "200" });
       Amount.Add(new SelectListItem { Text = "300 ml", Value = "300" });
       ViewBag.Amount = Amount;

       DonorDAL dal = new DonorDAL();
       List<SelectListItem> blood_list = new List<SelectListItem>();
       List<BloodModel> blood = dal.GetBlood();
       foreach (BloodModel item in blood)
       {
           blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
       }
       ViewBag.blood = blood_list;
       return View();
   }
  
        
    [HttpPost]
    public ActionResult MakeNewRequest(RequestDetailsModel m)
   {

       List<SelectListItem> Amount = new List<SelectListItem>();
       Amount.Add(new SelectListItem { Text = "100 ml", Value = "100" });
       Amount.Add(new SelectListItem { Text = "200 ml", Value = "200" });
       Amount.Add(new SelectListItem { Text = "300 ml", Value = "300" });
       ViewBag.Amount = Amount;

       DonorDAL dal = new DonorDAL();
       List<SelectListItem> blood_list = new List<SelectListItem>();
       List<BloodModel> blood = dal.GetBlood();
       foreach (BloodModel item in blood)
       {
           blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
       }
       ViewBag.blood = blood_list;

       m.RequestHospitalId = Convert.ToInt32(User.Identity.Name);
       BloodBankDAL l = new BloodBankDAL();
       l.MakeRequest(m);
       ViewBag.msg = "Request Made";
       return View();
   }
    public ActionResult MakeNewDonation()
    {
        List<SelectListItem> Amount = new List<SelectListItem>();
        Amount.Add(new SelectListItem { Text = "100 ml", Value = "100" });
        Amount.Add(new SelectListItem { Text = "200 ml", Value = "200" });
        Amount.Add(new SelectListItem { Text = "300 ml", Value = "300" });
        ViewBag.Amount = Amount;


        DonorDAL dal = new DonorDAL();
        List<SelectListItem> blood_list = new List<SelectListItem>();
        List<BloodModel> blood = dal.GetBlood();
        foreach (BloodModel item in blood)
        {
            blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
        }
        ViewBag.blood = blood_list;
        return View();
    }
     [HttpPost]
    public ActionResult MakeNewDonation(DonationDetailsModel m)
    {
        List<SelectListItem> Amount = new List<SelectListItem>();
        Amount.Add(new SelectListItem { Text = "100 ml", Value = "100" });
        Amount.Add(new SelectListItem { Text = "200 ml", Value = "200" });
        Amount.Add(new SelectListItem { Text = "300 ml", Value = "300" });
        ViewBag.Amount = Amount;

        DonorDAL dal = new DonorDAL();
        List<SelectListItem> blood_list = new List<SelectListItem>();
        List<BloodModel> blood = dal.GetBlood();
        foreach (BloodModel item in blood)
        {
            blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
        }
        ViewBag.blood = blood_list;

 
        m.DonorId = Convert.ToInt32(User.Identity.Name);
      
        BloodBankDAL l = new BloodBankDAL();
        l.MakeNewDonation(m);
        ViewBag.msg = "Donation Made";
        return View();
     
    }

     public ActionResult ViewRequest()
        {

         BloodBankDAL dal = new BloodBankDAL();
         List<RequestDetailsModel> list = dal.ViewRequest();
         if (list.Count == 0)
         {
             ViewBag.msg = "No Request Made";

         }
         return View(list);
        }

     public ActionResult ViewDonation()
     {
         BloodBankDAL dal = new BloodBankDAL();
         List<DonationDetailsModel> list = dal.ViewDonation();
        
         return View(list);
     }

        public ActionResult ViewDonationDetails()
     {
         int donorid = Convert.ToInt16(User.Identity.Name);
         DonorDAL dal = new DonorDAL();
         List<DonationDetailsModel> list = dal.ViewDonationDetails(donorid);
         if (list.Count == 0)
         {
             ViewBag.msg = "No Donations Made";

         }
            return View(list);
     }



        public ActionResult ViewHospitalRequestDetails()
     {
         int hospitalid = Convert.ToInt16(User.Identity.Name);
         HospitalDAL dal = new HospitalDAL();
         List<RequestDetailsModel> list = dal.ViewHospitalRequestDetails(hospitalid);
         if (list.Count == 0)
         {
             ViewBag.msg = "No Request Made";

         }
            return View(list);
     }

        public ActionResult ViewRequestDetails(int id)
     {

         BloodBankDAL dal = new BloodBankDAL();
         //int id = Convert.ToInt32(m.RequestBloodGroup);
         //string blood = dal.GetBloodGroup(id);
         //int hospitalid = Convert.ToInt32(m.RequestHospitalId);
         TempData["ReqId"] = id;
         int HID=dal.GetHId(id);
         string hospital = dal.GetHospital(HID);
         ViewBag.hospitalname =hospital;

         int BID = dal.GetBID(id);
         string blood = dal.GetBloodGroup(BID);
         ViewBag.bloodgroup = blood;
         TempData["blood"] = blood;

         string amt = dal.GetAmount(id);
         ViewBag.amount = amt;
         ViewBag.id = id;
         ViewBag.Bloodid = BID;
         return View();
     }
        public ActionResult CheckAvailability()

        {
            BloodBankDAL dal = new BloodBankDAL();
            ViewBag.bloodgroup = TempData["blood"];
            string blood = ViewBag.bloodgroup;
            List<DonationDetailsModel>list = dal.ShowAvailability(blood);
            if (list.Count == 0)
            {
                ViewBag.msg = "Not Available";

            }
           
                return View(list);
            
        }
    
        public ActionResult Allocate(int id)
        {
            BloodBankDAL dal = new BloodBankDAL();
            ViewBag.ReqId = TempData["ReqId"];
            dal.Allocation(id, ViewBag.ReqId);
            int allocationid=dal.AddAllocation(id, ViewBag.ReqId);
            string donorname = dal.GetDonorDetails(allocationid);
            string hospitalname = dal.GetHospitalDetails(allocationid);
            ViewBag.donor ="The Donated Donor is"+ donorname;
            ViewBag.hospital = "The Donation is made to" + hospitalname;
            return View();


        }

        [AllowAnonymous] 
        public ActionResult BloodTip()
        {
            return View();
        }
        [AllowAnonymous]
        public ActionResult SearchDonor()
        {
            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;

            List<SelectListItem> blood_list = new List<SelectListItem>();
            List<BloodModel> blood = dal.GetBlood();
            foreach (BloodModel item in blood)
            {
                blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
            }
            ViewBag.blood = blood_list;
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult SearchDonor(string SearchCity,string SearchBloodGroup)
        {
            DonorDAL dal = new DonorDAL();
            List<SelectListItem> cities_list = new List<SelectListItem>();
            List<CitiesModel> list = dal.GetCity();
            foreach (CitiesModel item in list)
            {
                cities_list.Add(new SelectListItem { Text = item.CityName, Value = Convert.ToString(item.CityId) });
            }
            ViewBag.cities = cities_list;

            List<SelectListItem> blood_list = new List<SelectListItem>();
            List<BloodModel> blood = dal.GetBlood();
            foreach (BloodModel item in blood)
            {
                blood_list.Add(new SelectListItem { Text = item.BloodName, Value = Convert.ToString(item.BloodId) });
            }
            ViewBag.blood = blood_list;
           
            
            List<DonorModel> donorlist = dal.SearchDonor(SearchCity,SearchBloodGroup);
            if (donorlist.Count == 0)
            { 
                ViewBag.msg = "Donor not Found"; 
            }
            return PartialView("SearchDonorPartial",donorlist);
        }
       
    }
}
