﻿using MyDonorAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyDonorAPI.Controllers
{
    public class donorsController : ApiController
    {

        private static List<donor> donorlist = new List<donor>()
        
        {   
            new donor() { donorId=1, donorName = "Meenu", gender = "Female", age = 22,bloodGroup="A positive" }, 
            
            new donor() { donorId=2, donorName = "Meena", gender = "Male", age = 22,bloodGroup="B positive"}, 
            
            new donor() { donorId=3, donorName = "Mani", gender = "Female", age = 22,bloodGroup="O positive" }, 
            
           
        };

        /// GET:donors
        /// <summary>
        ///  list of all donor
        /// </summary>
        ///<description> It shows list of all donor</description>
        /// <returns>donor list</returns>
        /// <response code="200">Ok</response>       
        /// <response code="400">BadRequest</response>
        /// <response code="500">InternalServerError</response>
        ///   <response code="404">NotFound</response>
        /// <remarks>
        ///    Donor List 
        ///     
        /// </remarks>

        [HttpGet]


        public HttpResponseMessage getDonor()
        {
            return donorlist.GetHttpResponseInstance();


        }

        /// GET:donors/id/
        /// <summary>
        ///  list of all donor
        /// </summary>
        /// <param name="id">Get and Set </param>
        ///<description> It shows list of all donor</description>
        ///
        /// <returns>return a particular donor by id</returns>
        /// <response code="200">Ok</response>       
        /// <response code="400">BadRequest</response>
        /// <response code="500">InternalServerError</response>
        /// <response code="404">NotFound</response>
        ///  <remarks>
        ///    Donor List 
        ///     
        /// </remarks>
        [HttpGet]

        public HttpResponseMessage getDonorById(int id)
        {


            donor pro = donorlist.Find(p => p.donorId == id);
            if (pro == null)
            {
                var error = new HttpResponseMessage(HttpStatusCode.NotFound);
                return error;
            }
            else
                return pro.GetHttpResponseInstance();

        }





        /// <summary>
        /// add a donor
        /// </summary>
        /// <param name="p"></param>
        /// <returns>New Created Todo Item</returns>
        /// <response code="201">Returns the newly created item</response>
        /// <response code="400">If the item is null</response>
        /// <response code="500">If the item is httpnull</response>
        /// <remarks>
        /// Donor List 
        ///     
        /// </remarks>
        [HttpPost]
        public HttpResponseMessage postDonor(donor p)
        {
            if (p == null)

                return new HttpResponseMessage(HttpStatusCode.BadRequest);

            donorlist.Add(p);

            return new HttpResponseMessage(HttpStatusCode.Created);

        }

        /// <summary>
        ///  list of all donor
        /// </summary>
        ///  <param name="id">Get and Set </param>
        ///<description> Delete a particular donor</description>
        /// <returns>donor list</returns>
        ///<response code="200">OK</response>
        /// <response code="400">Bad Request</response>
        /// <response code="404">Not Found Error</response>
        ///  <response code="500">Internal Server Error</response>
        /// <remarks>
        ///    Donor List 
        ///     
        /// </remarks>


        [HttpDelete]


        public HttpResponseMessage deleteDonor(int id)
        {
            donor pro = donorlist.Find(p => p.donorId == id);

            if (pro == null)
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            donorlist.Remove(pro);

            return new HttpResponseMessage(HttpStatusCode.OK);
        }


        /// <summary>
        ///  list of all donor
        /// </summary>
        ///   <param name="id">Get and Set </param>
        ///   <param name="p">Get and Set </param>
        ///<description> It shows list of all donor</description>
        ///<response code="200">OK</response>
        ///<response code="400">Bad Request</response>
        ///  <response code="404">Not Found Error</response>
        /// <response code="500">Internal Server Error</response>
        ///   /// <remarks>
        ///    Donor List 
        ///     
        /// </remarks>
        /// 

        [HttpPut]
        public HttpResponseMessage putDonor(int id, donor p)
        {
            donor pro = donorlist.Find(pr => pr.donorId == id);
            if (pro == null)
            {
                var error = new HttpResponseMessage(HttpStatusCode.NotFound);
                return error;
            }
            pro.donorId = p.donorId;
            pro.donorName = p.donorName;
            pro.gender = p.gender;
            pro.age = p.age;
            pro.bloodGroup = p.bloodGroup;
            return pro.GetHttpResponseInstance();
        } 


    }
}
