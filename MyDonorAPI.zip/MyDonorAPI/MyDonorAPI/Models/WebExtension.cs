﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace MyDonorAPI.Models
{
    public static class WebExtension
    {
        public static HttpResponseMessage GetHttpResponseInstance(this object objJsonNetResult)
        {

            HttpContext.Current.Response.Cache.VaryByHeaders["Accept-encoding"] = true;

            var stringContent = new StringContent(JsonConvert.SerializeObject(objJsonNetResult, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));

            var responseHttp = new HttpResponseMessage

            {

                StatusCode = HttpStatusCode.OK,

                Content = stringContent

            };


            responseHttp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");


            return responseHttp;

        }
    }
}