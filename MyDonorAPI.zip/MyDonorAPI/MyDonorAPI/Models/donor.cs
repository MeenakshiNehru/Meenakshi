﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyDonorAPI.Models
{
    public class donor
    {

        /// <summary>
        /// name=donorId
        /// position=1
        /// Description=this
        /// </summary>
        public int donorId { get; set; }

        /// <summary>
        /// name=donorName
        /// position=2
        /// Description=this
        /// </summary>
        public string donorName { get; set; }

        /// <summary>
        /// name=gender
        /// position=3
        /// Description=this
        /// </summary>
        public string gender { get; set; }


        /// <summary>
        /// name=age
        /// position=4
        /// Description=this
        /// </summary>
        public int age { get; set; }


        /// <summary>
        /// name=bloodGroup
        /// position=5
        /// Description=this
        /// </summary>
        public string bloodGroup { get; set; }
     
    }
}